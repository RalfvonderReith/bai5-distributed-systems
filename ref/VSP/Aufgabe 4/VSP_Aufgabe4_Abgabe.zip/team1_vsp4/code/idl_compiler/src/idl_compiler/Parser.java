package idl_compiler;

import idl_compiler.IDLCompiler.MethodData;
import idl_compiler.IDLCompiler.SupportedDataTypes;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;

import static idl_compiler.Log.log;

/**
 * Parser main class.
 *
 * @author (c) H. Schulz, 2016
 *         This programme is provided 'As-is', without any guarantee of any kind, implied or otherwise and is wholly unsupported.
 *         You may use and modify it as long as you state the above copyright.
 */
class Parser {

    public static final String BEGIN = "{";
    public static final String PARENTHESIS_OPEN = "\\(";
    public static final String PARENTHESIS_CLOSE = "\\)";

    private static final String fileName = "idl.files";
    private static final String BEGIN_REGEX = "\\{";
    private static final String END = "};";
    private static final String MODULE = "module";
    private static final String CLASS = "class";
    private static final String PARENTHESES = "[(|)]";
    private static final String PARAM_SEPARATOR = ",";

    /**
     * For printing compilation errors
     *
     * @param lineNo int
     * @param text   String
     */
    private static void printError(int lineNo, String text) {
        System.err.println("Line " + lineNo + ": " + text);
    }

    /**
     * Parse IDL Module in given file.
     *
     * @param in file reader
     * @return IDLmodule
     * @throws IOException ex
     */
    private static IDLmodule parseModule(IDLfileReader in) throws IOException {
        IDLclass newClass;

        String line = in.readLine();
        String tokens[] = (line.split(BEGIN_REGEX)[0]).trim().split(" ");

        if (tokens.length > 1 && tokens[0].equals(MODULE) && tokens[1] != null && tokens[1].length() > 0) {
            IDLmodule currentModule = new IDLmodule(tokens[1]);
            do {
                // parse containing classes
                newClass = parseClass(in, currentModule.getModuleName());
                if (newClass != null) currentModule.addClass(newClass);

                // try to read next module
                tokens = (line.split(BEGIN_REGEX)[0]).trim().split(" ");
            } while (newClass != null);

            return currentModule;


        }
        else {
            printError(in.getLineNo(), "Error parsing module. '" + line + "'");
            return null;
        }
    }

    /**
     * Parse (next) class in a file/module.
     *
     * @param in                file reader
     * @param currentModuleName name of the module currently being parsed.
     * @return the class parsed or null if there is no class left in the file
     * @throws IOException ex
     */
    private static IDLclass parseClass(IDLfileReader in, String currentModuleName) throws IOException {
        ArrayList<MethodData> methodList = new ArrayList<>();

        String line = in.readLine();
        if (line != null) {
            String tokens[] = (line.split(BEGIN_REGEX)[0]).trim().split(" ");
            if (tokens.length > 1 && tokens[0].equals(CLASS)
                    && tokens[1] != null && tokens[1].length() > 0) {
                // name of this class
                String className = tokens[1];

                // read methods
                line = in.readLine();
                while (line != null && !line.contains(END)) {
                    String[] tokens2 = line.trim().split(PARENTHESES);

                    String[] tokens3 = tokens2[0].split(" ");
                    String rTypeString = tokens3[0]; // return value
                    String methodName = tokens3[1]; // method name

                    SupportedDataTypes paramTypes[] = parseParams(in.getLineNo(), tokens2[1]);
                    String paramNames[] = parseParamNames(in.getLineNo(), tokens2[1]);

                    // into data container
                    methodList
                            .add(new MethodData(methodName, IDLCompiler.getSupportedTypeForKeyword(rTypeString), paramTypes, paramNames));
                    line = in.readLine();
                }

                // read class end
                if (line == null || !line.contains(END)) {
                    printError(in.getLineNo(), "Error parsing class "
                            + className + ": no end mark '" + line + "'");
                }

                // method data -> array
                MethodData methodArray[] = new MethodData[methodList.size()];

                //return IDL class
                return new IDLclass(className, currentModuleName,
                        methodList.toArray(methodArray));
            }
            else {
                if (line.contains(END)) {
                    return null;
                }
                else {
                    printError(in.getLineNo(), "Error parsing class.'" + line
                            + "'");
                    return null;
                }
            }
        }
        else {
            printError(in.getLineNo(), "Attempt to read beyond end of file.");
            return null;
        }
    }

    /**
     * Evaluate parameter list. (No reading done here!)
     *
     * @param lineNo    int
     * @param paramList String
     * @return SupportedDataTypes[]
     */
    private static SupportedDataTypes[] parseParams(int lineNo, String paramList) {
        if (paramList != null && paramList.length() > 0) {
            String[] paramEntries = paramList.trim().split(PARAM_SEPARATOR);

            // param data container
            SupportedDataTypes paramTypes[] = new SupportedDataTypes[paramEntries.length];

            for (int i = 0; i < paramEntries.length; i++) {
                String[] typeAndParamName = paramEntries[i].trim().split(" ");

                // 0: type, 1: name
                paramTypes[i] = idl_compiler.IDLCompiler.getSupportedTypeForKeyword(typeAndParamName[0]);
                if (paramTypes[i] == null) {
                    printError(lineNo, "Error parsing param list");
                    return null;
                }
            }
            return paramTypes;
        }
        else {
            return new SupportedDataTypes[0];  // empty list
        }
    }

    private static String[] parseParamNames(int lineNo, String paramList) {
        if (paramList != null && paramList.length() > 0) {
            String[] paramEntries = paramList.trim().split(PARAM_SEPARATOR);

            String paramNames[] = new String[paramEntries.length];

            for (int i = 0; i < paramEntries.length; i++) {
                String[] typeAndParamName = paramEntries[i].trim().split(" ");

                // 0: type, 1: name
                paramNames[i] = typeAndParamName[1];
                if (paramNames[i] == null) {
                    printError(lineNo, "Error parsing param list");
                    return null;
                }
            }
            return paramNames;
        }
        else {
            return new String[0];  // empty list
        }
    }

    /**
     * @param args String[]
     */
    public static void main(String[] args) {
        String IDLfileName = "";
        if (args != null && args.length > 0) {
            IDLfileName = args[0];
            IDLfileReader in = null;
            try {
                in = new idl_compiler.Parser.IDLfileReader(new FileReader(IDLfileName));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            log("trying to parse " + IDLfileName);
            IDLmodule module = null;  // Parse IDL file
            try {
                module = parseModule(in);
            } catch (IOException e) {
                e.printStackTrace();
            }

            // output of what we parsed from IDL file (just for testing)
//                printModule(module);
            log("trying to write class from " + IDLfileName);
            writeModuleFile(module);
        } else {

            log("trying to open " + fileName);
            try {
                BufferedReader br = new BufferedReader(new FileReader(fileName));
                while ((IDLfileName = br.readLine()) != null) {
                    log("trying to read " + IDLfileName);
                    IDLfileReader in = new IDLfileReader(new FileReader(IDLfileName));
                    log("trying to parse " + IDLfileName);
                    IDLmodule module = parseModule(in);  // Parse IDL file

                    // output of what we parsed from IDL file (just for testing)
//                printModule(module);
                    log("trying to write class from " + IDLfileName);
                    writeModuleFile(module);
                }
            } catch (FileNotFoundException e) {
                if (IDLfileName.equals(""))
                    log("Datei: '" + fileName + "' nicht gefunden...");
                else
                    log("Datei: '" + IDLfileName + "' nicht gefunden...");
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
//        String IDLfileName = "calc.idl";   //TODO should be parameterised.
//
//        try {
//            IDLfileReader in = new IDLfileReader(new FileReader(IDLfileName));
//            IDLmodule module = parseModule(in);  // Parse IDL file
//
//            // output of what we parsed from IDL file (just for testing)
//            printModule(module);
//
//
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
    }

    private static void writeModuleFile(IDLmodule module) {
        String filename = "idl_temp.java";
        String folder="";
        File f = new File(filename);
        f.delete();
        String newname = "";
        String s;
        try {
            log("trying to create file " + filename);
            FileWriter fw = new FileWriter(filename, true);
            System.out.println();
            log("writing code lines...");
            s = "package " + module.getModuleName() + ";\n\n";
            folder=module.getModuleName();
            System.out.print(s);
            fw.write(s);
            s = "import mware_lib.RemoteMethodCallObject;\n";
            System.out.print(s);
            fw.write(s);
            s = "import java.io.*;\n";
            System.out.print(s);
            fw.write(s);
            s = "import java.net.Socket;\n\n";
            System.out.print(s);
            fw.write(s);

            // classes
            IDLclass[] classes = module.getClasses();
            for (IDLclass aClass : classes) {
                newname = "_" + aClass.getClassName() + "ImplBase";
                s = "public abstract class " + newname + " {\n\n";
                System.out.print(s);
                fw.write(s);

                // methods
                MethodData[] methods = aClass.getMethods();
                for (MethodData method : methods) {
                    s = "    public abstract " + IDLCompiler.getSupportedJavaDataTypeName(method.getReturnType()) + " " + method.getName() + "(";
                    System.out.print(s);
                    fw.write(s);

                    // parameters
                    SupportedDataTypes[] paramTypes = method.getParamTypes();
                    String[] paramNames = method.getParamNames();
                    for (int m = 0; m < paramTypes.length; m++) {
                        if (m > 0) {
                            s = ", ";
                            System.out.print(s);
                            fw.write(s);
                        }
                        s = IDLCompiler.getSupportedJavaDataTypeName(paramTypes[m]) + " " + paramNames[m];
                        System.out.print(s);
                        fw.write(s);
                    }
                    s = ") throws RuntimeException;\n\n";
                    System.out.print(s);
                    fw.write(s);
                }
                s = "    public static _" + aClass.getClassName() + "ImplBase narrowCast(Object rawObjectRef) {\n";
                System.out.print(s);
                fw.write(s);
                s = "        if (rawObjectRef == null)\n";
                System.out.print(s);
                fw.write(s);
                s = "            return null;\n";
                System.out.print(s);
                fw.write(s);
                s = "        String[] remoteObject = ((String) rawObjectRef).split(\"/\");\n";
                System.out.print(s);
                fw.write(s);
                s = "        for (String s : remoteObject)\n";
                System.out.print(s);
                fw.write(s);
                s = "            if (s.equals(\"null\"))\n";
                System.out.print(s);
                fw.write(s);
                s = "                return null;\n\n";
                System.out.print(s);
                fw.write(s);
                s = "        class " + aClass.getClassName() + " extends _" + aClass.getClassName() + "ImplBase {\n\n";
                System.out.print(s);
                fw.write(s);
                for (MethodData method : methods) {
                    s = "            @Override\n";
                    System.out.print(s);
                    fw.write(s);
                    s = "            public " + IDLCompiler.getSupportedJavaDataTypeName(method.getReturnType()) + " " + method.getName() + "(";
                    System.out.print(s);
                    fw.write(s);
                    // parameters
                    SupportedDataTypes[] paramTypes = method.getParamTypes();
                    String[] paramNames = method.getParamNames();
                    for (int m = 0; m < paramTypes.length; m++) {
                        if (m > 0) {
                            s = ", ";
                            System.out.print(s);
                            fw.write(s);
                        }
                        s = IDLCompiler.getSupportedJavaDataTypeName(paramTypes[m]) + " " + paramNames[m];
                        System.out.print(s);
                        fw.write(s);
                    }
                    s = ") throws RuntimeException {\n";
                    System.out.print(s);
                    fw.write(s);
                    s = "                Serializable[] paras = {";
                    System.out.print(s);
                    fw.write(s);
                    for (int m = 0; m < paramTypes.length; m++) {
                        if (m > 0) {
                            s = ", ";
                            System.out.print(s);
                            fw.write(s);
                        }
                        s = paramNames[m];
                        System.out.print(s);
                        fw.write(s);
                    }
                    s = "};\n";
                    System.out.print(s);
                    fw.write(s);
                    s = "                Class<?>[] paramTypes = {";
                    System.out.print(s);
                    fw.write(s);
                    for (int m = 0; m < paramTypes.length; m++) {
                        if (m > 0) {
                            s = ", ";
                            System.out.print(s);
                            fw.write(s);
                        }
                        s = IDLCompiler.getSupportedJavaDataTypeName(paramTypes[m]) + ".class";
                        System.out.print(s);
                        fw.write(s);
                    }
                    s = "};\n";
                    System.out.print(s);
                    fw.write(s);
                    s = "                Object ret = fetchResult(remoteObject, \"" + method.getName() + "\", paras, paramTypes);\n";
                    System.out.print(s);
                    fw.write(s);
                    s = "                if (ret instanceof Exception)\n";
                    System.out.print(s);
                    fw.write(s);
                    s = "                    throw new RuntimeException((Exception) ret);\n";
                    System.out.print(s);
                    fw.write(s);
                    s = "                return (" + IDLCompiler.getSupportedJavaDataTypeName(method.getReturnType()) + ") ret;\n";
                    System.out.print(s);
                    fw.write(s);
                    s = "            }\n\n";
                    System.out.print(s);
                    fw.write(s);
                }

                s = "            private Object fetchResult(String[] remoteObject, String methodName, Serializable[] paras, Class<?>[] paramTypes) {\n";
                System.out.print(s);
                fw.write(s);
                s = "                Object ret;\n";
                System.out.print(s);
                fw.write(s);
                s = "                try {\n";
                System.out.print(s);
                fw.write(s);
                s = "                    Socket socket = new Socket(remoteObject[1], Integer.parseInt(remoteObject[2]));\n";
                System.out.print(s);
                fw.write(s);
                s = "                    ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());\n";
                System.out.print(s);
                fw.write(s);
                s = "                    ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());\n";
                System.out.print(s);
                fw.write(s);
                s = "                    RemoteMethodCallObject rmco = new RemoteMethodCallObject(remoteObject[0], methodName, paras, paramTypes);\n";
                System.out.print(s);
                fw.write(s);
                s = "                    oos.writeObject(rmco);\n";
                System.out.print(s);
                fw.write(s);
                s = "                    ret = ois.readObject();\n";
                System.out.print(s);
                fw.write(s);
                s = "                    oos.close();\n";
                System.out.print(s);
                fw.write(s);
                s = "                    ois.close();\n";
                System.out.print(s);
                fw.write(s);
                s = "                    socket.close();\n";
                System.out.print(s);
                fw.write(s);
                s = "                }\n";
                System.out.print(s);
                fw.write(s);
                s = "                catch (IOException | ClassNotFoundException e) {\n";
                System.out.print(s);
                fw.write(s);
                s = "                    return e;\n";
                System.out.print(s);
                fw.write(s);
                s = "                }\n";
                System.out.print(s);
                fw.write(s);
                s = "                return ret;\n";
                System.out.print(s);
                fw.write(s);
                s = "            }\n";
                System.out.print(s);
                fw.write(s);

                s = "        }\n";
                System.out.print(s);
                fw.write(s);
                s = "        return new " + aClass.getClassName() + "();\n";
                System.out.print(s);
                fw.write(s);
                s = "    }\n\n";
                System.out.print(s);
                fw.write(s);
                s = "}\n";
                System.out.print(s);
                fw.write(s);
            }
            fw.close();
            String newfilename = newname + ".java";
            if(folder.length()>0){
                new File(folder).mkdir();
                newfilename=folder+"/"+newfilename;
            }
            File oldfile = new File(filename);
            File newfile = new File(newfilename);
            newfile.delete();
            log("trying to rename file " + filename + " to " + newfilename);
            oldfile.renameTo(newfile);
            log("work done...");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * testing output & example on how to access class and method data of an IDL module.
     *
     * @param module IDLmodule
     */
    private static void printModule(IDLmodule module) {
        System.out.println();
        System.out.print("package " + module.getModuleName() + ";\n\n");

        // classes
        IDLclass[] classes = module.getClasses();
        for (IDLclass aClass : classes) {
            System.out.print("public abstract class _" + aClass.getClassName() + "ImplBase {\n\n");

            // methods
            MethodData[] methods = aClass.getMethods();
            for (MethodData method : methods) {
                System.out.print("    public abstract " + IDLCompiler.getSupportedJavaDataTypeName(method.getReturnType())
                        + " " + method.getName() + "(");

                // parameters
                SupportedDataTypes[] paramTypes = method.getParamTypes();
                String[] paramNames = method.getParamNames();
                for (int m = 0; m < paramTypes.length; m++) {
                    if (m > 0)
                        System.out.print(", ");
                    System.out.print(IDLCompiler.getSupportedJavaDataTypeName(paramTypes[m]) + " " + paramNames[m]);
                }
                System.out.print(");\n\n");
            }
            System.out.print("    public static _" + aClass.getClassName() + "ImplBase narrowCast(Object rawObjectRef) {\n");
            System.out.print("        return null;\n");// TODO code generieren
            System.out.print("    }\n\n");
            System.out.print("}\n");
        }
    }

    /**
     * File reader counting lines.
     *
     * @author (c) H. Schulz, 2016    This programme is provided 'As-is', without any guarantee of any kind, implied or otherwise and is wholly unsupported.  You may use and modify it as long as you state the above copyright.
     */
    @SuppressWarnings("JavaDoc")
    private static class IDLfileReader extends BufferedReader {

        /**
         * @uml.property name="lineNo"
         */
        private int lineNo;

        IDLfileReader(Reader in) {
            super(in);
            lineNo = 0;
        }

        public String readLine() throws IOException {
            lineNo++;
            return super.readLine();
        }

        /**
         * @return lineNo int
         * @uml.property name="lineNo"
         */
        int getLineNo() {
            return lineNo;
        }
    }

}
