package idl_compiler;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

class Log {

    static synchronized void log(String message) {
        String filename = "idl_compiler.log";
        try {
            FileWriter fw = new FileWriter(filename, true);
            String s = LocalDateTime.now() + " - " + message + "\r\n";
            System.out.print("IDL: " + s);
            fw.write(s);
            fw.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

}
