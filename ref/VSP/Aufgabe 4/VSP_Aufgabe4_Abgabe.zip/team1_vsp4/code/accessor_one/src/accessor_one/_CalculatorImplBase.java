package accessor_one;

import mware_lib.RemoteMethodCallObject;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;

public abstract class _CalculatorImplBase {

    public abstract double add(double a, double b) throws RuntimeException;

    public abstract String getStr(double a) throws RuntimeException;

    public static _CalculatorImplBase narrowCast(Object rawObjectRef) {
        if (rawObjectRef == null)
            return null;
        String[] remoteObject = ((String) rawObjectRef).split("/");
        for (String s : remoteObject)
            if (s.equals("null"))
                return null;

        class Calculator extends _CalculatorImplBase {

            @Override
            public double add(double a, double b) throws RuntimeException {
                Serializable[] paras = {a, b};
                Class<?>[] paramTypes = {double.class, double.class};
                Object ret = fetchResult(remoteObject, "add", paras, paramTypes);
                if (ret instanceof Exception)
                    throw new RuntimeException((Exception) ret);
                return (double) ret;
            }

            @Override
            public String getStr(double a) throws RuntimeException {
                Serializable[] paras = {a};
                Class<?>[] paramTypes = {double.class};
                Object ret = fetchResult(remoteObject, "getStr", paras, paramTypes);
                if (ret instanceof Exception)
                    throw new RuntimeException((Exception) ret);
                return (String) ret;
            }

            private Object fetchResult(String[] remoteObject, String methodName, Serializable[] paras, Class<?>[] paramTypes) {
                Object ret;
                try {
                    Socket socket = new Socket(remoteObject[1], Integer.parseInt(remoteObject[2]));
                    ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                    ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                    RemoteMethodCallObject rmco = new RemoteMethodCallObject(remoteObject[0], methodName, paras, paramTypes);
                    oos.writeObject(rmco);
                    ret = ois.readObject();
                    oos.close();
                    ois.close();
                    socket.close();
                }
                catch (IOException | ClassNotFoundException e) {
                    return e;
                }
                return ret;
            }
        }
        return new Calculator();
    }

}