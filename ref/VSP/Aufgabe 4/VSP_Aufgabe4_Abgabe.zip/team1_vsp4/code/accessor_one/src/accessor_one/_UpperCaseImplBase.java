package accessor_one;

import mware_lib.RemoteMethodCallObject;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;

public abstract class _UpperCaseImplBase {

    public static _UpperCaseImplBase narrowCast(Object rawObjectRef) {
        if (rawObjectRef == null)
            return null;
        String[] remoteObject = ((String) rawObjectRef).split("/");
        for (String s : remoteObject)
            if (s.equals("null"))
                return null;

        class UpperCase extends _UpperCaseImplBase {

            @Override
            public String toUpperCase(String lowerCase) throws RuntimeException {
                String registeredName = remoteObject[0];
                String serviceHost = remoteObject[1];
                int listenPort = Integer.parseInt(remoteObject[2]);
                Serializable[] paras = {lowerCase};
                Class<?>[] paramTypes = {String.class};
                Object ret = fetchResult(serviceHost, listenPort, registeredName, "toUpperCase", paras, paramTypes);
                if (ret instanceof Exception)
                    throw new RuntimeException();
                return (String) ret;
            }

            private Object fetchResult(String serviceHost, int listenPort, String registeredName, String methodName, Serializable[] paras, Class<?>[] paramTypes) {
                Object ret = null;
                try {
                    Socket socket = new Socket(serviceHost, listenPort);
                    ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                    ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                    RemoteMethodCallObject rmco = new RemoteMethodCallObject(remoteObject[0], methodName, paras, paramTypes);
                    oos.writeObject(rmco);
                    ret = ois.readObject();
                    oos.close();
                    ois.close();
                    socket.close();
                }
                catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                }
                return ret;
            }
        }
        return new UpperCase();
    }

    public abstract String toUpperCase(String lowerCase) throws RuntimeException;

}
