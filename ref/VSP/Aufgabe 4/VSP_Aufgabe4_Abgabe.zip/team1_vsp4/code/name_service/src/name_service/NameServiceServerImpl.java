package name_service;

import java.io.*;
import java.net.Inet4Address;
import java.net.ServerSocket;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static name_service.Log.log;

public class NameServiceServerImpl implements NameServiceServer, Runnable {

    private static final String fileName = "name_service.config";
    private static final int STANDARD_PORT = 11111;
    private static final int MIN_PORT = 1024;
    private static final int MAX_PORT = 65535;
    private final Map<String, AppHost> referenceMap;
    private volatile boolean running = false;
    private ServerSocket serverSocket = null;
    private int listenPort;

    private NameServiceServerImpl(int port) {
        listenPort = port;
        referenceMap = new ConcurrentHashMap<>();
    }

    public static void main(String[] args) {
        int port = STANDARD_PORT;
        if (args != null && args.length > 0)
            port = Integer.parseInt(args[0]);
        else {
            log("versuche '" + fileName + "' zu öffnen...");
            try {
                BufferedReader br = new BufferedReader(new FileReader(fileName));
                br.readLine();                          //1. Zeile ist die IP (kennt er selbst)
                port = Integer.parseInt(br.readLine()); //2. Zeile ist der Port
            }
            catch (FileNotFoundException e) {
                log("Datei: '" + fileName + "' nicht gefunden... benutze Standardport");
//                e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        log("config-Port: " + port);
        NameServiceServer server = new NameServiceServerImpl(port);
        Thread serverThread = new Thread(server);
        log("starte " + NameServiceServer.class.getSimpleName() + "-Thread...");
        serverThread.start();
        try {
            serverThread.join();
        }
        catch (InterruptedException e) {
            log(NameServiceServer.class.getSimpleName() + " beendet !!!");
        }
    }

    @Override
    public boolean isRunning() {
        return running;
    }

    @Override
    public int getListenPort() {//NameServiceServer kann autonom anderen Port wählen
        return listenPort;
    }

    @Override
    public synchronized void addReference(String name, AppHost appHost) {// Aufruf vom ConnectionHandler
        referenceMap.put(name, appHost);
        log(Thread.currentThread().getStackTrace()[1].getMethodName() + " -> " + name + " --- Anzahl der Remote-Objekte: " + referenceMap.size());
    }

    @Override
    public synchronized void removeReference(String name) {// Aufruf vom ConnectionHandler
        referenceMap.remove(name);
        log(Thread.currentThread().getStackTrace()[1].getMethodName() + " -> " + name + " --- Anzahl der Remote-Objekte: " + referenceMap.size());
    }

    @Override
    public AppHost getReferenceObject(String name) {// Aufruf vom ConnectionHandler
        log(Thread.currentThread().getStackTrace()[1].getMethodName() + "(" + name + ")");
        return referenceMap.keySet().contains(name) ? referenceMap.get(name) : null;
    }

    @Override
    public void run() {
        log("initialisiere Socket...");
        if (initialize()) {
            while (running) {
                try {
                    log("Warte auf Client...");
                    ConnectionHandler newConnection;
                    newConnection = new ConnectionHandlerImpl(serverSocket.accept(), this);// neuen Thread für diese Verbindung erzeugen
                    startConnThread(newConnection);
                }
                catch (IOException e) {
                    log("Geblockter Port: " + listenPort);
                    running = false;
                }
                catch (NullPointerException e) {
                    log("NullPointerException");
                    running = false;
                }
            }
        }
        try {
            serverSocket.close();
        }
        catch (IOException | NullPointerException ex) {
            log(ex.toString());
        }
        log("wird beendet...");
    }

    private synchronized void startConnThread(ConnectionHandler newConnection) {
        log("Neuer Client ist verbunden...");
        Thread tcch = new Thread(newConnection);
        newConnection.setThreadCCH(tcch);// sage dem Runnable zu welchem Thread er gehört
        tcch.start();
    }

    private boolean initialize() {
        int initialPort = listenPort;
        while (true) {// solange der gewählte Port belegt ist, erhöhe um 1
            try {
                serverSocket = new ServerSocket(listenPort);
                log("Neuen Socket auf Port: " + listenPort + " erstellt...");
                running = true;
                writeConfigFile();
                return true;
            }
            catch (IOException e) {
                log("Geblockter Port: " + listenPort);
                listenPort = (listenPort + 1) % MAX_PORT;
                if (listenPort < MIN_PORT) {//kleinere Ports sind für Nicht-Admins tabu
                    listenPort = MIN_PORT;
                }
                if (listenPort == initialPort)
                    return false;
            }
        }
    }

    private void writeConfigFile() {
        try {
            FileWriter fw = new FileWriter(fileName, false);
            fw.write(Inet4Address.getLocalHost().getHostAddress() + "\r\n");
            fw.write(listenPort + "\r\n");
            fw.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

}
