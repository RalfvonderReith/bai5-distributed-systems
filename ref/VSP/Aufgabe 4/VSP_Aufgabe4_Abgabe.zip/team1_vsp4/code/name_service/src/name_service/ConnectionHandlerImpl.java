package name_service;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicInteger;

import static name_service.Log.log;

class ConnectionHandlerImpl implements ConnectionHandler, Runnable {

    private static final String CHARSET = "UTF-8";
    private static final AtomicInteger NUM_OF_CCHS = new AtomicInteger(0);
    private final int id;
    private final Socket clientSocket;                  //Vom NameServiceServer erzeugter Socket
    private final NameServiceServer nameServiceServer;  //NameServiceServer-Instanz (für NameServiceServer-Befehle nötig)
    private final InetAddress userHost;
    private final int userPort;
    private volatile Thread tcch = null;                //eigener Thread (zum Terminieren)
    private InputStream inStream;
    private OutputStream outStream;
    private BufferedReader in;  //Vom Client kommende Nachrichten
    private PrintWriter out;    //Zum Client ausgehende Nachrichten
    private Thread timeOut;

    ConnectionHandlerImpl(Socket acceptedSocket, NameServiceServer nameServiceServer) {
        this.id = NUM_OF_CCHS.getAndIncrement();
        this.in = null;
        this.out = null;
        this.clientSocket = acceptedSocket;
        this.nameServiceServer = nameServiceServer;
        userHost = acceptedSocket.getInetAddress();
        userPort = acceptedSocket.getPort();
        log("CH" + id + ": Neuer Client '" + userHost + ":" + userPort + "' hat Verbindung zum " + NameServiceServer.class.getSimpleName() + " aufgenommen.");
    }

    @Override
    public Thread getThreadCCH() {
        return tcch;
    }

    @Override
    public void setThreadCCH(Thread tcch) {
        this.tcch = tcch;
    }

    @Override
    public InetAddress getUserHost() {
        return userHost;
    }

    @Override
    public int getUserPort() {
        return userPort;
    }

    @Override
    public void sendStream(String msg) {
        out.println(msg);
        log("CH" + id + ": >>> '" + msg + "' an  " + userHost + ":" + userPort + " gesendet.");
    }

    @Override
    public void terminate() {
        closeStreams();
    }

    private void close() {
        log("CH" + id + ": wird beendet...");
        closeStreams();
        NUM_OF_CCHS.decrementAndGet();
        stopTimeOut();
    }

    @Override
    public void run() {
        log("CH" + id + ": wird gestartet...");
        try {
            initialize();
        }
        catch (IOException e) {
            log("CH" + id + ": Fehler in I/O-Initialisierung ");
        }
        try {
            process();
        }
        catch (IOException e) {
            log("CH" + id + ": I/O-Fehler");
        }
        close();
    }

    private void startTimeOut() {
        timeOut = new Thread(new TimeOut(this));
        timeOut.start();// Wenn timeout-Thread lange genug läuft, beendet er diesen ConnectionHandler
    }

    private void stopTimeOut() {
        timeOut.interrupt();    // beende den timeout ...
        try {
            timeOut.join();
        }
        catch (InterruptedException ex) {
//            Logger.getLogger(ConnectionHandlerImpl.class.getRemoteHost()).log(Level.SEVERE, null, ex);
        }
    }

    private void process() throws IOException {
        startTimeOut();
        String line = null;
        while (line == null || line.isEmpty()) {
            line = in.readLine().trim();
        }
        log("CH" + id + ": <<< '" + line + "' von " + userHost + ":" + userPort + " erhalten.");
        stopTimeOut();
        startTimeOut();
        String[] msg = line.split("/");
        switch (msg[0]) {
            case "rebind":
                log("CH" + id + ":  sende an NSS: rebind " + msg[2]);
                nameServiceServer.addReference(msg[2], new AppHost(clientSocket.getInetAddress(), Integer.parseInt(msg[1])));
                sendStream("ok");
                break;
            case "resolve":
                log("CH" + id + ": resolve " + msg[1]);
                AppHost appHost = nameServiceServer.getReferenceObject(msg[1]);
                if (appHost != null) {
                    log("CH" + id + ": resolve " + msg[1] + " erfolgreich");
                    sendStream(msg[1] + appHost.getRemoteHost() + "/" + appHost.getRemotePort());
                }
                else {
                    log("CH" + id + ": resolve " + msg[1] + " NICHT erfolgreich !!!");
                    sendStream("");
                }
                break;
            default:
                log("CH" + id + ": unbekannter Befehl '" + msg[0] + "' !!!");
        }
        stopTimeOut();
    }

    private void initialize() throws IOException {
        inStream = clientSocket.getInputStream();
        outStream = clientSocket.getOutputStream();
        in = new BufferedReader(new InputStreamReader(inStream, CHARSET));
        out = new PrintWriter(new OutputStreamWriter(outStream, CHARSET), true);
        log("CH" + id + ": Input/Output erfolgreich initialisiert...");
    }

    private void closeStreams() {
        try {
            if (out != null) {
                outStream.close();
                out.close();
            }
            if (in != null) {
                inStream.close();
                in.close();
            }
            clientSocket.close();
        }
        catch (IOException e) {
            System.err.println("CH" + id + ": I/O-Beenden fehlgeschlagen !!!");
        }
    }

}
