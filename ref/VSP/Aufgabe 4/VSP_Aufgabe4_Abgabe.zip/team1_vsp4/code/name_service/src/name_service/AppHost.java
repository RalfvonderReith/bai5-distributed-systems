package name_service;

import java.net.InetAddress;

class AppHost {

    private final InetAddress remoteHost;
    private final int remotePort;

    AppHost(InetAddress remoteHost, int remotePort) {
        this.remoteHost = remoteHost;
        this.remotePort = remotePort;
    }

    InetAddress getRemoteHost() {
        return remoteHost;
    }

    int getRemotePort() {
        return remotePort;
    }

}
