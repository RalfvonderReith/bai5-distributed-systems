package name_service;

interface NameServiceServer extends Runnable {

    boolean isRunning();

    int getListenPort();

    void addReference(String name, AppHost appHost);

    void removeReference(String name);

    AppHost getReferenceObject(String name);

}
