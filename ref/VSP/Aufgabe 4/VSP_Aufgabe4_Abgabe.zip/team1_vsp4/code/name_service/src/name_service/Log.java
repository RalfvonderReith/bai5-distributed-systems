package name_service;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

class Log {

    private final static boolean debug = true;

    static synchronized void log(String message) {
        if (!debug)
            return;
        String filename = "name_service.log";
        try {
            FileWriter fw = new FileWriter(filename, true);
            String s = LocalDateTime.now() + " - NSS: " + message + "\r\n";
            System.out.print(s);
            fw.write(s);
            fw.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

}
