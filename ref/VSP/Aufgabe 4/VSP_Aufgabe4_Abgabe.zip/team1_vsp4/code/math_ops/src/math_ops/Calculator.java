package math_ops;

import accessor_one._CalculatorImplBase;

public class Calculator extends _CalculatorImplBase {

    @Override
    public double add(double a, double b) {
        if (a == 42.0)
            throw new IllegalArgumentException();
        return a + b;
    }

    @Override
    public String getStr(double a) {
        return String.valueOf(a);
    }
}
