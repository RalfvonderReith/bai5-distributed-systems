package math_ops;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

import static math_ops.Log.log;

class RemoteCall {

    private static final String CHARSET = "UTF-8";

    static synchronized String remoteResult(String msg, String serviceHost, int listenPort) {
        String answer = "";
        try {
            Socket clientSocket = new Socket(serviceHost, listenPort);
            OutputStream outStream = clientSocket.getOutputStream();
            PrintWriter out = new PrintWriter(outStream, true);
            try {
                InputStream inStream = clientSocket.getInputStream();
                BufferedReader in = new BufferedReader(new InputStreamReader(inStream, CHARSET));
                log("REM: Verbindung zum AppServer: '" + serviceHost + ":" + listenPort + "' erfolgreich.");
                log("REM: sende zum AppServer: " + msg);
                out.println(msg);
//            out.flush();
                try {
                    answer = in.readLine().trim();
                    log("REM: empfangen vom AppServer: " + answer);
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
            catch (IOException e) {
                log("REM: AppServer '" + serviceHost + ":" + listenPort + "' empfängt keine Daten !!!");
            }
            catch (NullPointerException e) {
                log("REM: connect() -> NullPointerException");
            }
        }
        catch (UnknownHostException e) {
            log("REM: Unbekannte Zieladresse: " + serviceHost);
        }
        catch (IOException e) {
            log("REM: AppServer '" + serviceHost + ":" + listenPort + "' sendet keine Daten !!!");
        }
        return answer;
    }

}
