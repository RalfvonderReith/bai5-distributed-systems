package math_ops;

import accessor_one._UpperCaseImplBase;

public class UpperCase extends _UpperCaseImplBase {

    @Override
    public String toUpperCase(String lowerCase) {
        return lowerCase.toUpperCase();
    }

}
