package math_ops;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

import static math_ops.AppServer.DEBUG;

class Log {

    static synchronized void log(String message) {
        if (!DEBUG)
            return;
        String filename = "math_ops.log";
        try {
            FileWriter fw = new FileWriter(filename, true);
            String s = LocalDateTime.now() + " - MOP: " + message + "\r\n";
            System.out.print(s);
            fw.write(s);
            fw.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

}
