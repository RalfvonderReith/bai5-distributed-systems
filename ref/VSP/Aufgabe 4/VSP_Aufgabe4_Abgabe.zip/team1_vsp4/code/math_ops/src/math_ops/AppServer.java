package math_ops;

import mware_lib.NameService;
import mware_lib.ObjectBroker;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;

import static math_ops.Log.log;

class AppServer {

    static final boolean DEBUG = true;
    private static final String fileName = "name_service.config";

    public static void main(String[] args) throws RemoteException {
        String host = "";
        int port = 0;
        if (args != null && args.length > 1) {
            host = args[0];
            port = Integer.parseInt(args[1]);
        }
        else {
            log("versuche '" + fileName + "' zu öffnen...");
            try {
                BufferedReader br = new BufferedReader(new FileReader(fileName));
                host = br.readLine();
                port = Integer.parseInt(br.readLine());
            }
            catch (FileNotFoundException e) {
                log("Datei: '" + fileName + "' nicht gefunden...");
                e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        log("Nameservice @ " + host + ":" + port);

// ### TEST start ###
        ObjectBroker objBroker = ObjectBroker.init(host, port, DEBUG);
        NameService nameSvc = objBroker.getNameService();
        nameSvc.rebind((Object) new Calculator(), "zumsel");
        nameSvc.rebind((Object) new UpperCase(), "uc");
// ### TEST end ###

        System.out.println("Eingabetaste zum beenden drücken und 10 s warten...");
        try {
            System.in.read();
        } catch (IOException e) {
            e.printStackTrace();
        }
        objBroker.shutDown();
    }
}