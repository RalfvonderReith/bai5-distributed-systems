package client;

import accessor_one._CalculatorImplBase;
import mware_lib.NameService;
import mware_lib.ObjectBroker;

import java.io.*;
import java.time.LocalDateTime;

class Client {

    private static final boolean DEBUG = true;
    private static final String fileName = "name_service.config";

    public static void main(String[] args) {
        String host = "";
        int port = 0;
        if (args != null && args.length > 1) {
            host = args[0];
            port = Integer.parseInt(args[1]);
        }
        else {
            log("versuche '" + fileName + "' zu öffnen...");
            try {
                BufferedReader br = new BufferedReader(new FileReader(fileName));
                host = br.readLine();
                port = Integer.parseInt(br.readLine());
            }
            catch (FileNotFoundException e) {
                log("Datei: '" + fileName + "' nicht gefunden...");
//            e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        log("Nameservice @ " + host + ":" + port);

// ### TEST start ###
        ObjectBroker objBroker = ObjectBroker.init(host, port, DEBUG);
        NameService nameSvc = objBroker.getNameService();
        Object rawObjRef = nameSvc.resolve("zumsel"); // generische Objektreferenz
        _CalculatorImplBase remoteObj = _CalculatorImplBase.narrowCast(rawObjRef);
// liefert klassenspezifisches Stellvertreterobjekt
        try { // Entfernter Methodenaufruf
            String s = remoteObj.getStr(1);
            log("--> Ergebnis: " + s);
        }
        catch (RuntimeException e) {
            log("--> "+e.getCause());
        }
        try { // Entfernter Methodenaufruf
            double s = remoteObj.add(42, 567);
            log("--> Ergebnis: " + s);
        }
        catch (RuntimeException e) {
            log("--> "+e.getCause());
        }
        try { // Entfernter Methodenaufruf
            double s = remoteObj.add(1, 567);
            log("--> Ergebnis: " + s);
        }
        catch (RuntimeException e) {
            log("--> "+e.getCause());
        }
// ### TEST end ###
        objBroker.shutDown();
    }

    private static synchronized void log(String message) {
        if (!DEBUG)
            return;
        String filename = "accessor_one.log";
        try {
            FileWriter fw = new FileWriter(filename, true);
            String s = LocalDateTime.now() + " - CLT: " + message + "\r\n";
            System.out.print(s);
            fw.write(s);
            fw.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}