package mware_lib;

import java.net.InetAddress;

interface ConnectionHandler extends Runnable {

    Thread getThreadCCH();

    void setThreadCCH(Thread tcch);

    InetAddress getUserHost();

    int getUserPort();

    void sendStream(String msg);

    void terminate();

}
