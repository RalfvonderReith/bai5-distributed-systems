package mware_lib;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

import static mware_lib.ObjectBroker.debug;

class Log {

    static synchronized void log(String message) {
        if (!debug)
            return;
        String filename = "mware_lib.log";
        try {
            FileWriter fw = new FileWriter(filename, true);
            String s = LocalDateTime.now() + " - MWL: " + message + "\r\n";
            System.out.print(s);
            fw.write(s);
            fw.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

}
