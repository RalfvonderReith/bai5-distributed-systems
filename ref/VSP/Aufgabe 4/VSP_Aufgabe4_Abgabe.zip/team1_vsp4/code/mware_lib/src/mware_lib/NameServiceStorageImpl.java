package mware_lib;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static mware_lib.Log.log;

public class NameServiceStorageImpl implements NameServiceStorage, Runnable {

    private static final String fileName = "name_service.config";
    private static final int STANDARD_PORT = 11111;
    private static final int MIN_PORT = 1024;
    private static final int MAX_PORT = 65535;
    private final Map<String, Object> objectMap;
    private volatile boolean running = false;
    private ServerSocket serverSocket = null;
    private int listenPort;

    NameServiceStorageImpl(int port) {
        listenPort = port;
        objectMap = new ConcurrentHashMap<>();
    }

    public static void main(String[] args) {
        int port = STANDARD_PORT;
        if (args != null && args.length > 0)
            port = Integer.parseInt(args[0]);
        else {
            log("STO: versuche '" + fileName + "' zu öffnen...");
            try {
                BufferedReader br = new BufferedReader(new FileReader(fileName));
                br.readLine();
                port = Integer.parseInt(br.readLine());
            }
            catch (FileNotFoundException e) {
                log("STO: Datei: '" + fileName + "' nicht gefunden... benutze Standardport");
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        log("STO: config-Port: " + port);
        NameServiceStorage server = new NameServiceStorageImpl(port);
        Thread serverThread = new Thread(server);
        log("STO: starte " + NameServiceStorage.class.getSimpleName() + "-Thread...");
        serverThread.start();
        try {
            serverThread.join();
        }
        catch (InterruptedException e) {
            log("STO: " + NameServiceStorage.class.getSimpleName() + " beendet !!!");
        }
    }

    @Override
    public void terminate(){
        running=false;
    }

    @Override
    public boolean isRunning() {
        return running;
    }

    @Override
    public int getListenPort() {//NameServiceStorage kann autonom anderen Port wählen
        return listenPort;
    }

    @Override
    public synchronized void addObject(String name, Object object) {// Aufruf vom ConnectionHandler
        objectMap.put(name, object);
        log("STO: " + Thread.currentThread().getStackTrace()[1].getMethodName() + " -> " + name + " --- Anzahl der Remote-Objekte: " + objectMap.size());
    }

    @Override
    public synchronized void removeObject(String name) {// Aufruf vom ConnectionHandler
        objectMap.remove(name);
        log("STO: " + Thread.currentThread().getStackTrace()[1].getMethodName() + " -> " + name + " --- Anzahl der Remote-Objekte: " + objectMap.size());
    }

    @Override
    public Object getObject(String name) {
        log("STO: " + Thread.currentThread().getStackTrace()[1].getMethodName() + "(" + name + ")");
        return objectMap.keySet().contains(name) ? objectMap.get(name) : null;
    }

    @Override
    public void run() {
        log("STO: initialisiere Socket...");
        if (initialize()) {
            while (running) {
                try {
                    log("STO: Warte auf Client...");
                    ConnectionHandler newConnection;
                    newConnection = new ConnectionHandlerImpl(serverSocket.accept(), this);//neuen Thread für diese Verbindung
                    startConnThread(newConnection);
                }
                catch (IOException e) {
                    log("STO: Geblockter Port: " + listenPort);
                    running = false;
                }
                catch (NullPointerException e) {
                    log("STO: NullPointerException");
                    running = false;
                }
            }
        }
        try {
            serverSocket.close();
        }
        catch (IOException | NullPointerException ex) {
            log("STO: " + ex);
        }
        log("STO: wird beendet...");
    }

    private synchronized void startConnThread(ConnectionHandler newConnection) {
        log("STO: Neuer Client ist verbunden...");
        Thread tcch = new Thread(newConnection);
        newConnection.setThreadCCH(tcch);//sage dem Runnable zu welchem Thread er gehört
        tcch.start();
    }

    private boolean initialize() {
        int initialPort = listenPort;
        while (true) {//solange der gewählte Port belegt ist, erhöhe um 1
            try {
                serverSocket = new ServerSocket(listenPort);
                log("STO: Neuen Socket auf Port: " + listenPort + " erstellt...");
                running = true;
                return true;
            }
            catch (IOException e) {
                log("STO: Geblockter Port: " + listenPort);
                listenPort = (listenPort + 1) % MAX_PORT;
                if (listenPort < MIN_PORT) {//kleinere Ports sind für Nicht-Admins tabu
                    listenPort = MIN_PORT;
                }
                if (listenPort == initialPort)
                    return false;
            }
        }
    }

}
