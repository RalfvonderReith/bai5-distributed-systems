package mware_lib;

interface NameServiceStorage extends Runnable {

    boolean isRunning();

    int getListenPort();

    void addObject(String name, Object object);

    void removeObject(String name);

    Object getObject(String name);

    void terminate();

}
