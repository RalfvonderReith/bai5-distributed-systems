package mware_lib;

import java.io.*;
import java.net.Inet4Address;
import java.net.Socket;
import java.net.UnknownHostException;

import static mware_lib.Log.log;

public class NameServiceOB extends NameService {

    private static final String CHARSET = "UTF-8";
    private final String serviceHost;
    private final int listenPort;
    private NameServiceStorage nameServiceStorage;
    private Thread nssThread;
    private PrintWriter out = null;
    private BufferedReader in = null;

    NameServiceOB(String serviceHost, int listenPort) {
        this.serviceHost = serviceHost;
        this.listenPort = listenPort;
    }

    @Override
    public void rebind(Object servant, String name) {
        log("NSO: " + Thread.currentThread().getStackTrace()[1].getMethodName() + " " + servant.getClass().getSimpleName() + " -> " + name);
        if (nameServiceStorage == null) {
            log("NSO: Erstelle " + NameServiceStorage.class.getSimpleName());
            nameServiceStorage = new NameServiceStorageImpl(listenPort + 1);
            nssThread = new Thread(nameServiceStorage);
            nssThread.start();
        }
        nameServiceStorage.addObject(name, servant);
        String erfolg = (String) sendRemote("rebind/" + nameServiceStorage.getListenPort(), name);
        if (erfolg != null && erfolg.equals("ok"))
            log("NSO: Remote-Bindung erfolgreich für: " + name);
        else
            log("NSO: Remote-Bindung NICHT erfolgreich für: " + name + " !!!");
    }

    @Override
    public Object resolve(String name) {
        String m = Thread.currentThread().getStackTrace()[1].getMethodName();
        log("NSO: " + m + "(" + name + ")");
        Object remoteObject = sendRemote("resolve", name);
        if (remoteObject != null && !remoteObject.equals("")) {
            log("NSO: " + m + " erfolgreich für: " + name + ":" + remoteObject);
            return remoteObject;
        }
        else {
            log("NSO: " + m + " NICHT erfolgreich für: " + name + " !!!");
            return null;
        }
    }

    public void shutDown() {
        if (nssThread == null)
            return;
        nameServiceStorage.terminate();
        nssThread.interrupt();
        try {
            new Socket(Inet4Address.getLocalHost().getHostAddress() ,nameServiceStorage.getListenPort());
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            nssThread.join();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private Object sendRemote(String method, String name) {
        log("NSO: Versuche Verbindung zum NameServiceServer: '" + serviceHost + ":" + listenPort + "' aufzubauen...");
        String answer = null;
        if (connect()) {
            log("NSO: Verbindung zum NameServiceServer: '" + serviceHost + ":" + listenPort + "' erfolgreich.");
            String s = method + "/" + name;
            log("NSO: sende zum NameServiceServer: " + s);
            out.println(s);
//            out.flush();
            try {
                while (answer == null) {
                    answer = in.readLine().trim();
                }
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        return answer;
    }

    private boolean connect() {
        boolean connected = false;
        try {
            Socket clientSocket = new Socket(serviceHost, listenPort);
            OutputStream outStream = clientSocket.getOutputStream();
            out = new PrintWriter(outStream, true);
            try {
                InputStream inStream = clientSocket.getInputStream();
                in = new BufferedReader(new InputStreamReader(inStream, CHARSET));
                connected = true;
            }
            catch (IOException e) {
                log("NSO: NameServiceServer '" + serviceHost + ":" + listenPort + "' empfängt keine Daten !!!");
            }
            catch (NullPointerException e) {
                log("NSO: connect() -> NullPointerException");
            }
        }
        catch (UnknownHostException e) {
            log("NSO: Unbekannte Zieladresse: " + serviceHost);
        }
        catch (IOException e) {
            log("NSO: NameServiceServer '" + serviceHost + ":" + listenPort + "' sendet keine Daten !!!");
        }
        return connected;
    }

}
