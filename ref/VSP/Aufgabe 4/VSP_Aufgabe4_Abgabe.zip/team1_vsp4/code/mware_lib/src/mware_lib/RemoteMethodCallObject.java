package mware_lib;

import java.io.Serializable;

public class RemoteMethodCallObject implements Serializable {

    private final String registeredName;
    private final String methodName;
    private final Serializable[] params;
    private final Class<?>[] paramTypes;

    public RemoteMethodCallObject(String registeredName, String methodName, Serializable[] params, Class<?>[] paramTypes) {
        this.registeredName = registeredName;
        this.methodName = methodName;
        this.params = params;
        this.paramTypes = paramTypes;
    }

    String getRegisteredName() {
        return registeredName;
    }

    String getMethodName() {
        return methodName;
    }

    Serializable[] getParams() {
        return params;
    }

    Class<?>[] getParamTypes() {
        return paramTypes;
    }

}
