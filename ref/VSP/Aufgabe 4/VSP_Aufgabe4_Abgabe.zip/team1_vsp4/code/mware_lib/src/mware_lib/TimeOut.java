package mware_lib;

import java.util.concurrent.TimeUnit;

import static mware_lib.Log.log;

class TimeOut implements Runnable {

    private static final int SECONDS_TO_WAIT = 10;
    private final ConnectionHandler connectionHandler;

    TimeOut(ConnectionHandler connectionHandler) {
        this.connectionHandler = connectionHandler;
    }

    @Override
    public void run() {
        try {
            log("TIM: Time out für " + connectionHandler.getUserHost() + ":" + connectionHandler.getUserPort() + " gestartet. Verbindung wird in " + SECONDS_TO_WAIT + " s beendet.");
            TimeUnit.SECONDS.sleep(SECONDS_TO_WAIT);
            log("TIM: !!! TERMINATING " + connectionHandler.getUserHost() + ":" + connectionHandler.getUserPort() + " !!!");
            connectionHandler.terminate();
            Thread t = connectionHandler.getThreadCCH();
            t.interrupt();
            t.join();
        }
        catch (Exception ex) {
//            log("TIM: Time out für '" + connectionHandler + "' wird beendet");
        }
        log("TIM: Time out für " + connectionHandler.getUserHost() + ":" + connectionHandler.getUserPort() + " wird beendet");
    }

}
