package mware_lib;

import static mware_lib.Log.log;

public class ObjectBroker { // - FrontEnd der Middleware -

    static boolean debug;
    private static ObjectBroker objectBroker;
    private static NameService nameService;

    private ObjectBroker() {
    }

    public static ObjectBroker init(String serviceHost,
                                    int listenPort, boolean debug) {
        // Das hier zurückgelieferte Objekt soll der zentrale Einstiegspunkt
        // der Middleware aus Applikationssicht sein.
        // Parameter: Host und Port, bei dem die Dienste (hier: Namensdienst)
        //            kontaktiert werden sollen. Mit debug sollen Test-
        //            ausgaben der Middleware ein- oder ausgeschaltet werden
        //            können.
        ObjectBroker.debug = debug;
        if (objectBroker == null) {
            log("OBR: Erstelle " + ObjectBroker.class.getSimpleName());
            objectBroker = new ObjectBroker();
            log("OBR: Erstelle " + NameServiceOB.class.getSimpleName());
            nameService = new NameServiceOB(serviceHost, listenPort);
        }
        return objectBroker;
    }

    public NameService getNameService() {
        // Liefert den Namensdienst (Stellvetreterobjekt).
        log("OBR: " + Thread.currentThread().getStackTrace()[1].getMethodName());
        return nameService;
    }

    public void shutDown() {
        // Beendet die Benutzung der Middleware in dieser Anwendung.
        log("OBR: Beende " + nameService.getClass().getSimpleName());
        nameService.shutDown();
        log("OBR: Beende " + ObjectBroker.class.getSimpleName());
    }
}
