package mware_lib;

public abstract class NameService { // - Schnittstelle zum Namensdienst -

    public abstract void rebind(Object servant, String name);
    // Meldet ein Objekt (servant) beim Namensdienst an.

    public abstract Object resolve(String name);
    // Liefert eine generische Objektreferenz zu einem Namen. (vgl. unten)

    public abstract void shutDown();
}