Der Vorfuehrungslauf sieht wie folgt aus:

0. Bitte waehlen Sie zuerst den Test Ordner als aktueller Ordner aus
> cd test

Dieser Ordner enthaelt die folgenden Dateien:

> ls -R
README.txt          app1.idl            idl_compiler.log    mware_lib           name_service.jar
app1                idl_compiler.jar    math_ops            name_service.config name_service.log

./app1:
Calculator1.class Client1.class

./math_ops:
_CalculatorImplBase$1Calculator.class _CalculatorImplBase.java
_CalculatorImplBase.class

./mware_lib:
ConnectionHandler.class      NameServiceOB.class          RemoteMethodCallObject.class
ConnectionHandlerImpl.class  NameServiceStorage.class     TimeOut.class
Log.class                    NameServiceStorageImpl.class
NameService.class            ObjectBroker.class
        -------------------

1. NameService starten:
	(bei Bedarf den Port vorher in "name_service.config" aendern -
	bei zur Laufzeit belegtem Port wird automatisch ein freier Port gesucht
	und in der .config-Datei gespeichert)
> java -jar name_service.jar [<port>]
    [<port>] ist optional und ist ansonsten auf 12001 gesetzt

Beispiel:
> java -jar name_service.jar
2016-12-23T02:11:27.718 - NSS: versuche 'name_service.config' zu öffnen...
2016-12-23T02:11:27.726 - NSS: config-Port: 12001
2016-12-23T02:11:27.728 - NSS: starte NameServiceServer-Thread...
2016-12-23T02:11:27.728 - NSS: initialisiere Socket...
2016-12-23T02:11:27.739 - NSS: Neuen Socket auf Port: 12001 erstellt...
2016-12-23T02:11:32.751 - NSS: Warte auf Client...
        -------------------

2. vom NameService geaenderte Datei "name_service.config" auf den/die AppServer und den/die Clients kopieren
    (in das gleiche Verzeichnis, wo sich die Packages befinden.)
        ------------------- 

3. die Test-IDL-Datei "app1.idl" mit folgendem Befehl in eine Java-Interface-Klasse übersetzen:
> java -jar idl_compiler.jar app1.idl
IDL: 2016-12-23T02:14:31.870 - trying to parse app1.idl
IDL: 2016-12-23T02:14:31.881 - trying to write class from app1.idl
IDL: 2016-12-23T02:14:31.882 - trying to create file idl_temp.java

IDL: 2016-12-23T02:14:31.882 - writing code lines...
... (Quellcode wird angezeigt)
IDL: 2016-12-23T02:14:31.884 - trying to rename file idl_temp.java to math_ops/_CalculatorImplBase.java
IDL: 2016-12-23T02:14:31.884 - work done...

Es wird "_CalculatorImplBase.java" im Ordner "math_ops" (=Package-Name) erzeugt.
        -------------------

4. dazu muss die "mware_lib" Package neben den anderen Packages sich befinden (Siehe 0.)
        -------------------

5. Die Java-Datei wird in eine Java-Class-Datei kompiliert:
> javac ./math_ops/_CalculatorImplBase.java
        -------------------

6. AppServer starten:
> java app1.Calculator1 localhost 12001
Press ENTER to exit...
(Mit der “ENTER” Eingabetaste wird der Server nach 10-Sek Timeout beendet)
        -------------------

7. Client starten:
> java app1.Client1 localhost 12001
s=690.0
d=433.0
java.lang.RuntimeException: Runtime exception ( saw -1 ...)
Press ENTER to exit...
(Mit der “ENTER” Eingabetaste wird der Client sofort beendet)
        -------------------

Alle 3 Anwendungen koennen auf unterschiedlichen Computern laufen.
