-module(cmem).
%-compile(export_all).	% ersetzen durch -export(...).
-export ([initCMEM/2, getClientNNr/2, updateClient/4, delCMEM/1]).

%% -------------------------------------------
% CMEM (Client-Memory)
%% -------------------------------------------
%%
%% -------------------------------------------
%%
% Merkt sich fuer jeden Leser welche Nachrichten-Nr er bereits erhalten hat
% Wird vom Server gestartet
%

% Initialisiert CMEM Modul
initCMEM(RemTime, _) ->
	{RemTime,[]}.

% Liefert die naechste Nachrichtennummer, die an die ClientID geschickt werden soll
getClientNNr({_RemTime,ClientList},ClientID) ->
%	io:format("CMEM>>> getClientNNr: clientlist ~p~n clientid ~p~n",[ClientList,ClientID]),
	io:format("CMEM>>> getClientNNr: clientid ~p~n",[ClientID]),
	getMsgId(ClientID, ClientList).
	
getMsgId(_, []) ->
	1; % LAUT AUFGABENSTELLUNG: Ist der Client unbekannt, wird die 1 zurueckgegeben! <- OK
getMsgId(ClientID, ClientList) ->
%	io:format("CMEM>>> GetMsgId: ClientList: ~p~n",[ClientList]),
%	io:format("CMEM>>> 1 Element des Tupels fuer ClientID ~p: ~p~n",[ClientID,lists:keyfind(ClientID, 1, ClientList)]),
	ClientFound = lists:keyfind(ClientID, 1, ClientList),
	NextMsgId = if 	ClientFound == false -> 
						1;
					true ->
						{_, MsgId, _} = ClientFound,
						MsgId
				end,
	io:format("CMEM>>> Next message number for client ~p, is  : ~p~n", [ClientID, NextMsgId]),
	NextMsgId.

% Aktualisiert die ClientID mit der NNr
updateClient({RemTime,ClientList},ClientID,NNr,_) ->
	{RemTime,updateClient_(ClientList,ClientID,NNr)}.

updateClient_([],ClientID,NNr) ->
%	[{ClientID,NNr,erlang:now()}];
	[{ClientID,NNr,erlang:system_time()}];

updateClient_([{ExistID,_,_}|T],ClientID,NNr) when ExistID == ClientID ->
%	[{ExistID,NNr,erlang:now()}] ++ T;
	[{ExistID,NNr,erlang:system_time()}] ++ T;

updateClient_([{ExistID,NNr1,TStamp}|T],ClientID,NNr2) ->
	[{ExistID,NNr1,TStamp}] ++ updateClient_(T,ClientID,NNr2).

% Die Clients, die RemTime ueberschritten, werden geloescht
delCMEM({RemTime,ClientList}) ->
%	CurrentTime = werkzeug:now2UTC(erlang:now()),
	CurrentTime = erlang:system_time(),
	GetLiveClients = fun({_ClientID,_LastMessageNumer, TimeStamp}) -> (CurrentTime - TimeStamp) < RemTime * 1000   end,
	NewClientList = lists:filter(GetLiveClients,ClientList),
	{RemTime,NewClientList}.