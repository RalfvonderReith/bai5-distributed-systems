Starten:
--------------------
alle .beam Dateien im Verzeichnis l�schen
Die Dateien client.cfg und server.cfg anpassen (den Computernamen nach '@' ersetzen)
Eingabeaufforderung / Konsole starten

HBQ-Node starten:
erl -name hbqNode -setcookie server
ins Verzeichnis wechseln:
(hbqNode@...)1> cd("/home/students/abv312/Downloads/A1").
(hbqNode@...)2> make:all().

Server-Node starten:
erl -name server -setcookie server
ins Verzeichnis wechseln:
(server@...)1> cd("C:/BAI-5/VS/Praktikum/A1").
(server@...)2> make:all().
(server@...)3> server:start().

Client-Node starten:
erl -name client -setcookie server
ins Verzeichnis wechseln:
(redakteur1@...)1> cd("C:/BAI-5/VS/Praktikum/A1").
(redakteur1@...)2> make:all().
(redakteur1@...)3> client:run().


Die verschiedenen Nodes k�nnen zu Test-Zwecken auf ein- und demselben Computer gestartet werden.
In der Praxis werden sie auf verschiedenen Computern gestartet.

Runterfahren:
-------------
2> Ctrl/Strg Shift G
-->q

Informationen zu Prozessen:
-------------
2> pman:start().
2> process_info(PID).

Kompilieren:
-------------
1> c(<Dateiname>).

Entfernter Aufruf:
-------------
1> net_adm:ping('node@ProfDrKlauck').
2> PID = {host,'node@ProfDrKlauck'}.
3> demoRemote:rpc(PID,call).

