-module(server).
%-compile(export_all).	% ersetzen durch -export([start/0]).
-export([start/0,stop/0]).

%% -------------------------------------------
% Server
%% -------------------------------------------
%%
%% -------------------------------------------
%%
% Bekommt Nachrichten von Redakteuren und verschickt diese an Leser
% Aufruf: 	server:start().
%
start() ->
	CFGFile = "server.cfg",															io:format("~nServer wurde gestartet ...~n~n"),
	{ok, HostName} = inet:gethostname(),
	Datei = lists:concat(["Server@",HostName,".log"]),								io:format("Logging-Datei-Name :                         '~p'~n",[Datei]),
%	{ok, ConfigListe} = file:consult(CFGFile), werkzeug:logging(Datei, "Server: "++CFGFile++" geöffnet...\r\n"),
	case file:consult(CFGFile) of
		{ok, ConfigListe} -> werkzeug:logging(Datei,"Server: "++CFGFile++" geöffnet...\r\n");
		{error, {Line, Mod, Term}} -> ErrMSG = lists:concat(["Server: "++CFGFile++" Fehler in Zeile ",werkzeug:to_String(Line),
															 " Mod ",werkzeug:to_String(Mod)," Term ",werkzeug:to_String(Term)]),
										werkzeug:logging(Datei,ErrMSG),
										ConfigListe = [];
		{error, Something} -> ErrMSG = lists:concat(["Server: "++CFGFile++" Fehler:",werkzeug:to_String(Something),"\r\n"]),
							  werkzeug:logging(Datei,ErrMSG),
							  ConfigListe = [];
		_error -> ConfigListe = []
	end,
	{ok, Latency} = werkzeug:get_config_value(latency, ConfigListe),				io:format("Latency         aus '"++CFGFile++"' ausgelesen: '~p'~n",[werkzeug:to_String(Latency)]),
	{ok, ClientLifetime} = werkzeug:get_config_value(clientlifetime, ConfigListe),	io:format("Client-Lifetime aus '"++CFGFile++"' ausgelesen: '~p'~n",[werkzeug:to_String(ClientLifetime)]),
	{ok, ServerName} = werkzeug:get_config_value(servername, ConfigListe),			io:format("Server-Name     aus '"++CFGFile++"' ausgelesen: '~p'~n",[ServerName]),
	{ok, HBQname} = werkzeug:get_config_value(hbqname, ConfigListe),				io:format("HBQ-Name        aus '"++CFGFile++"' ausgelesen: '~p'~n",[HBQname]),
	{ok, HBQnode} = werkzeug:get_config_value(hbqnode, ConfigListe),				io:format("HBQ-Node        aus '"++CFGFile++"' ausgelesen: '~p'~n",[HBQnode]),
	{ok, DLQlimit} = werkzeug:get_config_value(dlqlimit, ConfigListe),				io:format("DLQ-Limit       aus '"++CFGFile++"' ausgelesen: '~p'~n~n",[werkzeug:to_String(DLQlimit)]),
	
	net_adm:ping(HBQnode),
	timer:sleep(500),
	_HBQpid = spawn(HBQnode, fun() -> hbq:start() end),
	timer:sleep(1000),
	ServerPid = spawn(fun() -> startS(Datei,Latency,ClientLifetime,{HBQname,HBQnode}) end),
	register(ServerName,ServerPid).

stop() ->
	self() ! shutdown. % geht nicht !!!!!!!!!!!!!!!!!!!
	
startS(Datei,Latency,ClientLifetime,HBQ) ->
	Text = "Server: Startzeit: "++werkzeug:timeMilliSecond()++" mit PID "++pid_to_list(self())++"\r\n",
	werkzeug:logging(Datei, Text),
	HBQ ! {self(), {request,initHBQ}},										% 01 out
	Timer = werkzeug:reset_timer(null, Latency, shutdown),
	initHBQ(Datei,Latency,Timer,ClientLifetime,HBQ).

	
initHBQ(Datei,Latency,Timer,ClientLifetime,HBQ) ->
	receive
		{reply,ok} -> 														% 03 in
			werkzeug:logging(Datei, "Server: HBQ konnte initialisiert werden.\r\n"),
%			io:format("initCMEM ~p~n",[ClientLifetime]),
			CMEM = cmem:initCMEM(ClientLifetime, Datei),					% 04
			loop(Datei,Latency,CMEM,Timer,ClientLifetime,1,HBQ)
	end.

	
loop(Datei,Latency,CMEM,Timer,ClientLifetime,NNr,HBQ) ->
%   forget timed-out clients
	cmem:delCMEM(CMEM),
%	io:format("Server: Timer zurückgesetzt um:~p~n",[werkzeug:timeMilliSecond()]),
	TimerNeu = werkzeug:reset_timer(Timer, Latency, shutdown),
	receive
	
		{ClientPID,getmsgid} ->												% 05 in
			ClientPID ! {nid,NNr},											% 06 out
			Text = lists:concat(["Server: Nachrichtennummer ",werkzeug:to_String(NNr)," an ",pid_to_list(ClientPID)," gesendet\r\n"]), werkzeug:logging(Datei, Text),
			loop(Datei,Latency,CMEM,TimerNeu,ClientLifetime,NNr+1,HBQ);
			
		{dropmessage,[INNr,Msg,TSclientout]} ->								% 07 in
			Message = [INNr,Msg,TSclientout], %io:format("Server: Nachricht-Nr ~p erhalten ~n",[INNr]),%	io:format("Server: Nachricht erhalten: ~n~p~n",[Message]),
			dropmessage(Message,HBQ),
			Text = lists:concat(["Server: Nachricht ",werkzeug:to_String(INNr)," wurde in HBQ eingefügt.\r\n"]), werkzeug:logging(Datei, Text),
			loop(Datei,Latency,CMEM,TimerNeu,ClientLifetime,NNr,HBQ);		
			
		{ClientPID, getmessages} ->											% 10 in
			NewCMEM = getmessages(ClientPID,HBQ,CMEM,Datei),
			loop(Datei,Latency,NewCMEM,TimerNeu,ClientLifetime,NNr,HBQ);	
			
		shutdown ->
			shutdown(HBQ,Datei);
			
		Anything -> 
			Text = lists:concat(["Server: loop unbekannte Nachricht erhalten: '",werkzeug:to_String(Anything),"'\r\n"]), werkzeug:logging(Datei, Text),
			loop(Datei,Latency,CMEM,Timer,ClientLifetime,NNr,HBQ)
			
	end.

dropmessage(Message,HBQ) ->
	HBQ ! {self(), {request,pushHBQ,Message}},								% 08 out
	receive
		{reply, ok} -> 														% 09 in
			1==1 %io:format("Server: {reply, ok} von HBQ erhalten.~n")
	end.

getmessages(ClientPID,HBQ,CMEM,Datei) ->
%	io:format("Server: Nachrichtenanfrage erhalten - rufe cmem:getClientNNr auf mit CMEM:~p - ClientPID:~p~n",[CMEM,ClientPID]),
%	io:format("Server: Nachrichtenanfrage erhalten - rufe cmem:getClientNNr für ClientPID:~p~n",[ClientPID]),
	CNNr = cmem:getClientNNr(CMEM, ClientPID),								% 11
	io:format("Server: Die nächste Nachricht für Client ~p soll >= Nr. ~p sein...~n", [ClientPID,CNNr]),
	HBQ ! {self(), {request,deliverMSG,CNNr,ClientPID}},					% 12 out
	receive
		{reply, SendNNr} -> 												% 17 in
			Text = lists:concat(["Server: Nachricht ",werkzeug:to_String(SendNNr)," wurde zugestellt.\r\n"]), werkzeug:logging(Datei, Text),
			if SendNNr =/= 0 -> cmem:updateClient(CMEM,ClientPID,SendNNr+1,Datei); % 18
				true 		 -> CMEM
			end
	end.

shutdown(HBQ,Datei) ->
	HBQ ! {self(), {request,dellHBQ}},										% 19 out
	receive
		{reply,ok} -> 
			werkzeug:logging(Datei, "Server: keine eingehenden Anfragen. Server terminiert sich um "++werkzeug:timeMilliSecond()++".\r\n")
%			unregister(ServerName);
	end.

