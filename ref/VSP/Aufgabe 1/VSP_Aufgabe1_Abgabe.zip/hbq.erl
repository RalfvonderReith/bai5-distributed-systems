-module(hbq).
-compile(export_all).	% ersetzen durch -export(...).
%-export([start/0]).

%% -------------------------------------------
% HBQ (Hold-Back-Queue)
%% -------------------------------------------
%%
%% -------------------------------------------
%%
% Speichert die Nachrichten, die NICHT verteilt werden sollen (weil eine ältere Nachricht noch nicht eingetroffen ist)
% Wird vom Server gestartet
%
start() ->
	CFGFile = "server.cfg",												io:format("HBQ wurde gestartet ...~n"),
	{ok, HostName} = inet:gethostname(),
	Datei = lists:concat(["HB-DLQ@",HostName,".log"]),					io:format("Logging-Datei-Name :                         '~p'~n",[Datei]),
	case file:consult(CFGFile) of
		{ok, ConfigListe} -> werkzeug:logging(Datei,"HBQ>>> "++CFGFile++" geöffnet...\r\n");
		{error, {Line, Mod, Term}} -> ErrMSG = lists:concat(["HBQ>>> "++CFGFile++" Fehler in Zeile ",werkzeug:to_String(Line),
															 " Mod ",werkzeug:to_String(Mod)," Term ",werkzeug:to_String(Term)]),
										werkzeug:logging(Datei,ErrMSG),
										ConfigListe = [];
		{error, Something} -> ErrMSG = lists:concat(["HBQ>>> "++CFGFile++" Fehler:",werkzeug:to_String(Something),"\r\n"]),
							  werkzeug:logging(Datei,ErrMSG),
							  ConfigListe = [];
		_error -> ConfigListe = []
	end,
%	{ok, ConfigListe} = file:consult(CFGFile), werkzeug:logging(Datei, "HBQ>>> "++CFGFile++" geöffnet...\r\n"),
	{ok, HBQname} = werkzeug:get_config_value(hbqname, ConfigListe),	io:format("HBQ-Name        aus '"++CFGFile++"' ausgelesen: '~p'~n",[HBQname]),
	{ok, DLQlimit} = werkzeug:get_config_value(dlqlimit, ConfigListe),	io:format("DLQ-Limit       aus '"++CFGFile++"' ausgelesen: '~p'~n~n",[DLQlimit]),

	register(HBQname,self()),
	initHBQ(Datei,DLQlimit).												% 02
%	loop(Datei,DLQ).
	
initHBQ(Datei,DLQlimit) ->
	receive
	
		{ServerPID, {request,initHBQ}} ->									% 01 in
			werkzeug:logging(Datei, "HBQ>>> initialisiert worden von "++pid_to_list(ServerPID)++".\r\n"),
			DLQ = dlq:initDLQ(DLQlimit,Datei),									
			ServerPID ! {reply,ok},											% 03 out
%			io:format("HBQ>>> init-reply an Server "++pid_to_list(ServerPID)++" gesendet ...~n"),
			loop(Datei,[],DLQ);
			
		Anything -> 
			Text = lists:concat(["HBQ>>> initHBQ unbekannte Nachricht erhalten: '",Anything,"'\r\n"]), werkzeug:logging(Datei, Text),
			initHBQ(Datei,DLQlimit)
			
	end.
	
loop(Datei,HBQ,DLQ) ->
	receive
	
		{ServerPID, {request,pushHBQ,[NNr,Msg,TSclientout]}} ->				% 08 in
			Message = [NNr,Msg,TSclientout,werkzeug:timeMilliSecond()],% io:format("HBQ>>> Nachricht-Nr. ~p erhalten~n",[NNr]),%			io:format("HBQ>>> Nachricht erhalten: ~p~n",[Message]),
			{NewHBQ, NewDLQ} = pushHBQ(Message,HBQ,DLQ,Datei),
			ServerPID ! {reply, ok},										% 09 out
			loop(Datei,NewHBQ,NewDLQ);

		{ServerPID, {request,deliverMSG,NNr,ToClient}} ->					% 12 in
			SendNNr = deliverMSG(NNr, ToClient, DLQ, Datei),
			ServerPID ! {reply,SendNNr},									% 17 out
			loop(Datei,HBQ,DLQ);
			
		{ServerPID, {request,dellHBQ}} ->									% 19 in
			{_Size,MsgList} = DLQ,
			Text = lists:concat(["HBQ>>> Downtime: ", werkzeug:timeMilliSecond(), " von HBQ und DLQ ", pid_to_list(self()),"; Anzahl Restnachrichten HBQ/DLQ:0/",werkzeug:to_String(length(MsgList))," (",werkzeug:to_String(length(MsgList)),").\r\n"]),
			werkzeug:logging(Datei,Text),
			_EmptyDLQ = dellHBQ(DLQ),
			ServerPID ! {reply,ok};
			
		Anything -> 
			Text = lists:concat(["HBQ>>> loop unbekannte Nachricht erhalten: '",Anything,"'\r\n"]),
			werkzeug:logging(Datei, Text),
			loop(Datei,HBQ,DLQ)
			
	end.
	
	
% Fuegt die Msg mit Nummer und dem Sende-Zeitstempel in die HBQ ein. 
pushHBQ(Message,HBQ,DLQ,Datei) ->
	NewSortedHBQ = lists:sort(HBQ ++ [Message]),		% besser wäre, erst dann sortieren, wenn nachrichten in die dlq sollen... (erst mal so lassen)
%	io:format("HBQ>>> NewSortedHBQ ~n~p~n",[NewSortedHBQ]),
	Text = lists:concat(["HBQ>>> Nachricht ",erlang:hd(Message)," in HBQ eingefügt.\r\n"]), werkzeug:logging(Datei, Text),
	pushDLQ(NewSortedHBQ, DLQ, Datei).
%			if 
%				checkTwoThirds(HBQ, Size) ->
%					NewDLQ = pushDLQ(Message,DLQ,Datei),
%					NewHBQ = delFrontMsgOfHBQ(HBQ),
%					ServerPID ! {reply, hbqpushok},										% 09 out
%					loop(Datei,DLQlimit,NewHBQ,NewDLQ);
%					NewDLQ = 				!!!!!!! nicht an dieser stelle - nur, wenn eine nachricht vom leser angefordert wird -> dann wird die dlq aufgefüllt (so viel, wie geht...)
%				true ->
%					NewDLQ = pushDLQ(Message,DLQ,Datei),
%					NewHBQ = delFrontMsgOfHBQ(HBQ),
%					ServerPID ! {reply, hbqpushok},										% 09 out
%					loop(Datei,DLQlimit,NewHBQ,NewDLQ)
%			end;

deliverMSG(NNr, ToClient, DLQ, Datei) ->
% frage die dlq: bist du leer?
% 	wenn ja,dann{
% 			gibt mir die expected-nr (sie sagt 35)
% 			push nachricht 35 - 89 (90 = lücke)
% }
% dlq:deliverMSG ..
	dlq:deliverMSG(NNr, ToClient, DLQ, Datei).								% 15


% Prueft auf die Luecke und uebergibt die Nachrichten an DLQ weiter
pushDLQ(HBQ, {Size, Queue}, Datei) ->
	DLQ = {Size, Queue},
%	io:format("HBQ>>> pushDLQ ~p~n",[DLQ]),
	ExpectedMsgNr = dlq:expectedNr(DLQ),
	[FirstMsgNr, Msg, TSclientout, TShbqin] = firstElem(HBQ),
	{NewHBQ, NewDLQ} = case {ExpectedMsgNr == FirstMsgNr, checkTwoThirds(HBQ, Size)} of
		{true, _} ->
			DLQ_ = dlq:push2DLQ([FirstMsgNr, Msg, TSclientout, TShbqin], DLQ, Datei),
			HBQ_ = lists:filter(fun([Nr, _, _, _]) -> Nr =/= FirstMsgNr end, HBQ),
			werkzeug:logging(Datei,"HBQ>>> HBQ wurde komplett in DLQ übertragen.\r\n"),
			{HBQ_, DLQ_};
		{false, false} ->
			{HBQ, DLQ};
		{false, true} ->
%			{MsgJoin, HBQ_} = joinMissingMsg(HBQ),
			{HBQ_, ReadyToDLQ} = getGroupedMsgs(HBQ),
			ErrorMsg = [ExpectedMsgNr, "***Fehlernachricht fuer Nachrichtennummern " ++ werkzeug:to_String(ExpectedMsgNr) ++ " bis " ++ werkzeug:to_String(FirstMsgNr-1) ++ " um " ++ werkzeug:timeMilliSecond() ++ ".\r\n","00.00 00:00:00,000|","00.00 00:00:00,000|"],
			DLQmeldung = pushJoinToDLQ([ErrorMsg] ++ ReadyToDLQ, DLQ, Datei),
			werkzeug:logging(Datei,"HBQ>>>  Fehlernachricht fuer Nachrichten " ++ werkzeug:to_String(ExpectedMsgNr) ++ " bis " ++ werkzeug:to_String(FirstMsgNr-1) ++ " generiert.\r\n"),
			{HBQ_, DLQmeldung}
	end,
	{NewHBQ, NewDLQ}.
 
getGroupedMsgs([FirstMsg | RestHBQ]) ->
	if length([FirstMsg | RestHBQ]) == 1 ->
		{[],[FirstMsg | RestHBQ]};
		true -> 
			FirstElemNr = erlang:hd(FirstMsg),
			SecondElemNr = erlang:hd(erlang:hd(RestHBQ)),
			if SecondElemNr > FirstElemNr + 1 -> {RestHBQ, [FirstMsg]};
						 true -> 
							{RestQ,FirstM} = getGroupedMsgs(RestHBQ),
							{RestQ, [FirstMsg] ++ FirstM}
			end
	end.
 
joinMissingMsg([H | T]) ->
	io:format("HBQ>>> Die erste Lücke innerhalb der Holdbackqueue wird behandelt.~n"),
	LastElem = erlang:tl(H ++ T),
	joinMissingMsg_(H ++ T, LastElem, [], 0);
joinMissingMsg([]) ->
	io:format("HBQ>>> Es gibt keine Lücken in der leeren HBQ!~n"),
	{[], []}.

joinMissingMsg_([H | T], [_H | _T], Accu, Counter) ->
	[NNr, _, _, _] = H,
	[_NNr, _, _, _] = _H,
	case {erlang:abs(NNr - _NNr) > 1, Counter == 1} of
		{true, true} ->
			{Accu ++ H, _H ++ _T};
		{true, false} ->
			NewAccu = Accu ++ informOfError(NNr, _NNr),
			joinMissingMsg_(T, _T, NewAccu, Counter + 1);
		{false, true} ->
			joinMissingMsg_(T, _T, Accu ++ H, Counter);
		{false, false} ->
			joinMissingMsg_(T, _T, Accu ++ H, Counter)
	end;
joinMissingMsg_([H | _], [], _, _) ->
	H.

pushJoinToDLQ(MsgJoin, DLQ, Datei) ->
	pushJoinToDLQ_(MsgJoin, DLQ, Datei).

pushJoinToDLQ_([H | T], DLQ, Datei) ->
	NewDLQ = dlq:push2DLQ(H, DLQ, Datei),
	pushJoinToDLQ_(T, NewDLQ, Datei);
pushJoinToDLQ_([], DLQ, _) ->
	DLQ.	

informOfError(NNr, _NNr) ->
	{_NNr, "Fehlernachricht von:" ++ NNr ++ " bis" ++ "_NNr", "Error", "Error"}.  

emptyMessage() ->
	[0,"no message","00.00 00:00:00,000","00.00 00:00:00,000"].
	
% Hilfsmethode, um das erste Element von einer Liste zurueckzugeben. 
% Falls die Liste leer ist, wird 1 zurueckgegeben
firstElem([]) ->
	emptyMessage();
firstElem(List) ->
	erlang:hd(List).

% Hilfsmethode, um die Laenge der HBQ mit der Laenge von DLQ zu vergleichen
checkTwoThirds(HBQ, Size) ->
  erlang:length(HBQ) >= 2 / 3 * Size.
	
% Terminiert den HBQ-Prozess
dellHBQ(DLQ)->
	dlq:delDLQ(DLQ).