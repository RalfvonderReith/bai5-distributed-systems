-module(client).
-compile(export_all).	% ersetzen durch -export([start/0]).
%-export([r/0,l/0]).

%% -------------------------------------------
% Client
%% -------------------------------------------
%% Enthaelt 2 Rollen: Leser und Redakteur
%% -------------------------------------------
%%
% Leser: Empfängt Nachrichten von einem Server und gibt diese aus
% Redakteur: Sendet Nachrichten an einen Server
% Aufruf: 	client:start().
%

	
start() ->
	CFGFile = "client.cfg",	io:format("~nClient-Starter wurde gestartet ...~n~n"),
	{ok, HostName} = inet:gethostname(),
	Datei = lists:concat(["Client@",HostName,".log"]),								io:format("Logging-Datei-Name :                         '~p'~n",[Datei]),
%	{ok, ConfigListe} = file:consult(CFGFile), io:format(CFGFile++" geöffnet...\r\n"),
	case file:consult(CFGFile) of
		{ok, ConfigListe} -> werkzeug:logging(Datei,CFGFile++" geöffnet...\r\n");
		{error, {Line, Mod, Term}} -> ErrMSG = lists:concat([CFGFile++" Fehler in Zeile ",werkzeug:to_String(Line),
															 " Mod ",werkzeug:to_String(Mod)," Term ",werkzeug:to_String(Term)]),
										werkzeug:logging(Datei,ErrMSG),
										ConfigListe = [];
		{error, Something} -> ErrMSG = lists:concat([CFGFile++" Fehler:",werkzeug:to_String(Something),"\r\n"]),
							  werkzeug:logging(Datei,ErrMSG),
							  ConfigListe = [];
		_error -> ConfigListe = []
	end,
	{ok, Clients} = werkzeug:get_config_value(clients, ConfigListe),				io:format("Clients         aus '"++CFGFile++"' ausgelesen: '~p'~n",[Clients]),
	{ok, ClientLifetime} = werkzeug:get_config_value(lifetime, ConfigListe),		io:format("Server-Lifetime aus '"++CFGFile++"' ausgelesen: '~p'~n",[ClientLifetime]),
	{ok, ServerName} = werkzeug:get_config_value(servername, ConfigListe),			io:format("Server-Name     aus '"++CFGFile++"' ausgelesen: '~p'~n",[ServerName]),
	{ok, ServerNode} = werkzeug:get_config_value(servernode, ConfigListe),			io:format("Server-Node     aus '"++CFGFile++"' ausgelesen: '~p'~n",[ServerNode]),
	{ok, Sendeintervall} = werkzeug:get_config_value(sendeintervall, ConfigListe),	io:format("Sendeintervall  aus '"++CFGFile++"' ausgelesen: '~p'~n",[Sendeintervall]),
	
	net_adm:ping(ServerNode),
	timer:sleep(500),
	ServerID = {ServerName, ServerNode}, io:format("Server -> '~p'~n",[ServerID]),
	SMSG = lists:concat(["Servernode ",werkzeug:to_String(ServerNode)," von Server ",werkzeug:to_String(ServerName),"\r\n"]),
	werkzeug:logging(Datei,SMSG),
%	start_clients(Datei,Clients,ServerID).
	start_client(ServerID,Clients,ClientLifetime,Sendeintervall,0,Datei).
	
start_client(_ServerID,Clients,_ClientLifetime,_Sendeintervall,Clients,Datei) ->
	MSG = lists:concat(["Alle ",Clients," Clients gestartet\r\n"]),
	werkzeug:logging(Datei,MSG);
	
start_client(ServerID,Clients,ClientLifetime,Sendeintervall,Anzahl,Datei) ->
	Bezeichner = lists:concat(["Client_",Anzahl,node()]),
	CDatei = string:concat(Bezeichner,".log"),
	ClientPid = spawn(fun() -> startC(ServerID,ClientLifetime,Sendeintervall,Anzahl,CDatei) end),
	timer:kill_after(ClientLifetime*1000,ClientPid),
%	if Anzahl > 0 -> spawn(fun() -> startC(Typ,ServerID,ClientLifetime,Sendeintervall,Anzahl,CDatei) end);
%	   true -> spawn(fun() -> startCF(Typ,ServerID,ClientLifetime,Sendeintervall,Anzahl,CDatei) end)
%	end,
	MSG = lists:concat(["Client ",Bezeichner," gestartet\r\n"]),
	werkzeug:logging(Datei,MSG),
	start_client(ServerID,Clients,ClientLifetime,Sendeintervall,Anzahl+1,Datei).

	
startC(Server,ClientLifetime,Sendeintervall,Anzahl,Datei) ->
	{ok, HostName} = inet:gethostname(),
	Text = lists:concat([Anzahl,"-client@",HostName,"-",pid_to_list(self()),"-C-3-01 Start: ",werkzeug:timeMilliSecond(),".\r\n"]),
	werkzeug:logging(Datei,Text),
	redakteur(Server,ClientLifetime,Sendeintervall,Anzahl,Datei,1).

	
redakteur(Server,ClientLifetime,Sendeintervall,Anzahl,Datei,MeineNNr) ->
	Server ! {self(),getmsgid},												% 05 out
	receive
		{nid,Number} ->														% 06 in
			io:format("NNr ~p von Server erhalten~n",[Number]),
			io:format("meine NNr ~p ~n",[MeineNNr]),
			if MeineNNr rem 6 == 0 ->
					Msg = lists:concat([Number,"te_Nachricht um ",werkzeug:timeMilliSecond(),"- vergessen zu senden ******\r\n"]),
					werkzeug:logging(Datei,Msg),
					NewFreq = trunc(changeMsgFreq(Datei,Sendeintervall)),
					timer:sleep(NewFreq*1000),
					leser(Server,ClientLifetime,NewFreq,Anzahl,Datei);
				true ->
					TSclientout = werkzeug:timeMilliSecond(),
					{ok, HostName} = inet:gethostname(),
					Msg = lists:concat([Anzahl,"-client@",HostName,"-",pid_to_list(self()),"-C-3-01: ",Number,"te_Nachricht. Sendezeit: ",werkzeug:timeMilliSecond(),"(",Number,")\r\n"]),
					werkzeug:logging(Datei,Msg),
					Server ! {dropmessage,[Number,Msg,TSclientout]},				% 07 out
					NewFreq = trunc(changeMsgFreq(Datei,Sendeintervall)),
					timer:sleep(NewFreq*1000),
					redakteur(Server,ClientLifetime,NewFreq,Anzahl,Datei,MeineNNr+1)
			end;
		Anything -> 
			Text = lists:concat(["Client: redakteur unbekannte Nachricht erhalten: '",Anything,"'\r\n"]),
			werkzeug:logging(Datei, Text),
			redakteur(Server,ClientLifetime,Sendeintervall,Anzahl,Datei,MeineNNr)		
	end.

leser(Server,ClientLifetime,Sendeintervall,Anzahl,Datei) ->
	Server ! {self(), getmessages},											% 10 out
	receive
		{reply,[NNr,_Msg,TSclientout,TShbqin,TSdlqin,TSdlqout],Terminated} ->% 16 in
%			io:format("Nachricht-Nr ~p von Server erhalten:~p~n",[NNr,[NNr,_Msg,TSclientout,TShbqin,TSdlqin,TSdlqout]]),
			{ok, HostName} = inet:gethostname(),
%			Text = lists:concat([Anzahl,"-client@",HostName,"-",pid_to_list(self()),"-C-3-01: ",NNr,"te_Nachricht erhalten. Empfangszeit: ",werkzeug:timeMilliSecond(),"(",NNr,")\r\n"]),
			Text = lists:concat([Anzahl,"-client@",HostName,"-",pid_to_list(self()),"-C-3-01: ",NNr,"te_Nachricht. C Out: ",TSclientout," HBQ In: ",TShbqin," DLQ In: ",TSdlqin," DLQ Out: ",TSdlqout,".*******; C In: ",werkzeug:timeMilliSecond(),")\r\n"]),
			werkzeug:logging(Datei,Text),
			NewFreq = trunc(changeMsgFreq(Datei,Sendeintervall)),
			timer:sleep(NewFreq*1000),		% !!!!!!!!!! TEST Leser warten länger, um Überlauf zu simulieren... (zeile vor Abgabe entfernen) !!!!!!!!!!!!!!!!!!!!!!!!
			if Terminated == true ->
					redakteur(Server,ClientLifetime,NewFreq,Anzahl,Datei,1);
				true ->
					leser(Server,ClientLifetime,NewFreq,Anzahl,Datei)
			end;
%			Server ! shutdown;
		Anything -> 
			Text = lists:concat(["Client: leser unbekannte Nachricht erhalten: '",Anything,"'\r\n"]),
			werkzeug:logging(Datei, Text),
			leser(Server,ClientLifetime,Sendeintervall,Anzahl,Datei)		
	end.
	
changeMsgFreq(Datei, Sendeintervall) ->
	Random = random:uniform(),
	HalfInterval = Sendeintervall / 2,
	NewFreq = if Random > 0.5 -> Sendeintervall + HalfInterval + 2;
			   true -> (Sendeintervall - HalfInterval) + 2
	end,
	werkzeug:logging(Datei,"Neues Sendeintervall: " ++ werkzeug:to_String(NewFreq) ++ " Sekunden (" ++ werkzeug:to_String(Sendeintervall) ++ ").\r\n"),
	NewFreq.
