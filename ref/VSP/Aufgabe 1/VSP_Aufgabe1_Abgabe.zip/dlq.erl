-module(dlq).
-compile(export_all).	% ersetzen durch -export(...).
%-export([initDLQ/2, delDLQ/1, expectedNr/1, push2DLQ/3, deliverMSG/4]).

%% -------------------------------------------
% DLQ (Delivery-Queue)
%% -------------------------------------------
%%
%% -------------------------------------------
%%
% Speichert die Nachrichten, die verteilt werden sollen
% Wird vom Server gestartet
%

% Liefert eine neue leere DLQ-ADT zurueck
initDLQ(Size,Datei) ->
	Text = lists:concat(["dlq>>> initialisiert mit Kapazität ",Size,".\r\n"]),
	werkzeug:logging(Datei, Text),
	{Size,[]}.
	%initDLQ_(Size,[]).

%initDLQ_(Size,Akku) when Size < 1 -> Akku;
%initDLQ_(Size,Akku) -> initDLQ_(Size-1,Akku ++ [emptyMessage()]).

%emptyMessage() ->
%	[0,"no message","00.00 00:00:00,000","00.00 00:00:00,000","00.00 00:00:00,000","00.00 00:00:00,000"].


% Terminiert die DLQ
delDLQ(_DLQ)->
	{0,[]}.
	
% Naechste zu speichernde Nachrichtennummer wird an HBQ-Prozess zurückgegeben
expectedNr({_,List}) ->
	expectedNr_(List).
	
expectedNr_([]) ->
	1;
expectedNr_(List) ->
%	io:format("dlq>>> expectedNr from List ~p~n",[List]),
	ReversedList = lists:reverse(List),
	Msg = erlang:hd(ReversedList),
	NNr = erlang:hd(Msg),
	NNr+1.
	
% Die Nachricht von HBQ wird in die DLQ eingefügt
push2DLQ(NewMsg, {Size,List}, Datei) when length(List) < Size ->
	io:format("dlq>>> push2DLQ - no shift~p~n",[NewMsg]),
	[MsgNr|_] = NewMsg,
	werkzeug:logging(Datei, "dlq>>> Nachricht " ++ werkzeug:to_String(MsgNr) ++ " in DLQ eingefügt.\r\n"),
	{Size, List ++ compose(NewMsg)};
push2DLQ(NewMsg, {Size,[FirstMsg|ListTail]}, Datei) ->
	io:format("dlq>>> push2DLQ - shift~n"),
	[MsgNr|_] = NewMsg,
	werkzeug:logging(Datei, "dlq>>> Nachricht " ++ werkzeug:to_String(MsgNr) ++ " in DLQ eingefügt.\r\n"),
	werkzeug:logging(Datei, "dlq>>> Nachricht " ++ werkzeug:to_String(erlang:hd(FirstMsg)) ++ " aus DLQ gelöscht.\r\n"),
	{Size, ListTail ++ compose(NewMsg)}.

compose([NNr, Msg, TSclientout, TShbqin]) ->
%	[[NNr, Msg ++ werkzeug:timeMilliSecond(), TSclientout, TShbqin, erlang:now()]].
	[[NNr, Msg ++ werkzeug:timeMilliSecond(), TSclientout, TShbqin, werkzeug:timeMilliSecond()]].
	
% Sendet die Nachricht mit der bestimmten Nummer an den Client
deliverMSG(MsgNr, ClientPID, {_Size,List}, Datei) ->
	io:format("dlq>>> DLQ tries to send a message nr ~p~n",[MsgNr]),
%	werkzeug:logging(Datei, "dlq>>> DLQ tries to send a message nr " ++ werkzeug:to_String(MsgNr) ++ "\r\n"),
	TempNr = expectedNr_(List),
	if 	MsgNr < TempNr ->	deliverMSG_(MsgNr, ClientPID, List, List, Datei);
							true  -> 	werkzeug:logging(Datei,"dlq>>> DLQ sent fake message\r\n"),
%										ClientPID ! {reply,[MsgNr-1, "no message", erlang:now(), erlang:now(), erlang:now(), erlang:now()], true},
										ClientPID ! {reply,[0, "no message", "00.00 00:00:00,000","00.00 00:00:00,000","00.00 00:00:00,000","00.00 00:00:00,000"], true},
										0
	end.

% Wenn keine solche Nummer, probiere naechste Nachricht zu versenden
deliverMSG_(MsgNr, ClientPID, [], List, Datei) ->
	deliverMSG_(MsgNr+1, ClientPID, List, List, Datei);
deliverMSG_(MsgNr, ClientPID, [[NNr, Msg, TSclientout, TShbqin, TSdlqin]|_], List, Datei) when MsgNr == NNr ->
	werkzeug:logging(Datei, "dlq>>> Nachricht " ++ werkzeug:to_String(MsgNr)++" an Client"++pid_to_list(ClientPID) ++ " ausgeliefert.\r\n"),
%	ClientPID ! {reply,[NNr, Msg, TSclientout, TShbqin, TSdlqin, erlang:now()], MsgNr > expectedNr_(List)-1},
	ClientPID ! {reply,[NNr, Msg, TSclientout, TShbqin, TSdlqin, werkzeug:timeMilliSecond()], MsgNr == expectedNr_(List)-1},
	MsgNr;
deliverMSG_(MsgNr, ClientPID, [_|Tail], List, Datei) ->
	deliverMSG_(MsgNr, ClientPID, Tail, List, Datei).