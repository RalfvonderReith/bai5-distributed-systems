Starten:
--------------------
(w)erl -(s)name wk -setcookie zummsel
1> demoRemote:start(<Name>).
1> demoMSGQ:start().


Runterfahren:
-------------
2> Ctrl/Strg Shift G
-->q

Informationen zu Prozessen:
-------------
2> pman:start().
2> process_info(PID).

Kompilieren:
-------------
1> c(<Dateiname>).

Entfernter Aufruf:
-------------
1> net_adm:ping('node@ProfDrKlauck').
2> PID = {host,'node@ProfDrKlauck'}.
3> demoRemote:rpc(PID,call).

