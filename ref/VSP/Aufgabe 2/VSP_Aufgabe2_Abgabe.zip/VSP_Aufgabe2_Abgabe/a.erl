-module(a).
-compile(export_all).

kill() ->
	tellChef(kill).

reset() ->
	tellChef(reset).
	
step() ->																			% 07 out
	tellChef(step).
	
prompt() ->
	tellChef(prompt).
	
nudge() ->
	tellChef(nudge).
	
toggle() ->
	tellChef(toggle).
	
calc(WggT) ->
	tellChef({calc, WggT}).
	
tellChef(Msg) ->
	{ok, Config} = file:consult("koordinator.cfg"),
	{ok, NameserviceNode} = werkzeug:get_config_value(nameservicenode, Config),
	{ok, NameserviceName} = werkzeug:get_config_value(nameservicename, Config),
	{ok, KoordinatorName} = werkzeug:get_config_value(koordinatorname, Config),
	
	Found = erlang:whereis(manCtrl),
	case Found of
		undefined ->
			erlang:register(manCtrl, self()),
			net_adm:ping(NameserviceNode),
			timer:sleep(1000);
		_ -> ok
	end,
	
	Nameservice = global:whereis_name(NameserviceName),
	Koordinator = findKoordinator(Nameservice, KoordinatorName),
	Koordinator ! Msg.
	
findKoordinator(Nameservice, KoordinatorName) ->
	Nameservice ! {erlang:self(), {lookup, KoordinatorName}},
	receive
		{pin,{Name,Node}} ->
			io:format("Koordinator gefunden.\n"),
			{Name,Node};
		not_found -> io:format("Koordinator nicht gefunden.\n")
	end.
	
	