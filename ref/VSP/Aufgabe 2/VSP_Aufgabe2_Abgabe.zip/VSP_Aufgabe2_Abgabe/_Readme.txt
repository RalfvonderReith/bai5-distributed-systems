Starten des Namensdienstes:
--------------------------
(w)erl -(s)name ns -setcookie zummsel
1>nameservice:start().


Starten des Koordinators:
--------------------------
(w)erl -(s)name ko -setcookie zummsel
2>k:start().

% liest die koordinator.cfg ein:
% {arbeitszeit, 3}:		simulierte Arbeitszeit f�r die ggT-Berechnung
% {termzeit, 3}:			Wenn termzeit keine Berechnung dann wird Terminierungsabstimmung initiiert
% {ggtprozessnummer, 42}:	Anzahl ggT Prozesse je Starter (und default ggT)
% {nameservicenode, 'ns@KI-VS'}:	node des Namensdienstes
% {nameservicename, nameservice}:	Name des Namensdienstes
% {koordinatorname, chef}:		Name des Koordinators
% {quote, 80}:			Abstimmungsquote fuer Terminierung
% {korrigieren, 0}:		Korigiert falsche Terminierungsmeldungen (== 1)

Starten der ggT-Prozesse: 
(g.erl Datei, die vom Starter ausgef�hrt wird, geh�rt zu der Abgabe von Michael Strutzke)
--------------------------
(w)erl -(s)name ggt -setcookie zummsel
3>s:go(Anzahl,Start)

- Anzahl: Anzahl der Starter auf einer Node ab Start+1
- aufruf von s:start(Starternummer)
- aufruf von g:start(ArbeitsZeit, TermZeit, PraktikumsGruppe, TeamNummer, GGTProzessnummer, Starternummer, NameS, Koordinator, Quote)

% ggt_starter liest die ggt.cfg ein:
% {praktikumsgruppe, 4}:	Nummer des Praktikums
% {teamnummer, 88}:		Nummer des Teams
% {nameservicenode, ns@Brummpa}:	node des Namensdienstes
% {koordinatorname, chef}:	Name des Koordinators


Wechsel zur Initialisierung: 
--------------------------
4>a:step()


Berechung des ggTs: 
--------------------------
5>a:calc(Zahl)


Runterfahren:
-------------
2> Ctrl/Strg Shift G
-->q
