-module(g).
-compile(export_all).	% ersetzen durch -export([start/0]).

start(ArbeitsZeit,TermZeit,Praktikumsgruppe,Teamnummer,GGTProzessnummer,Starternummer,{NameserviceName, NameserviceNode},Koordinator, Quote) ->
%	io:format("ggt gestartet.\n"),
%	GGTProzessName = werkzeug:to_String(Praktikumsgruppe) ++ werkzeug:to_String(Teamnummer) ++ werkzeug:to_String(GGTProzessnummer) ++ werkzeug:to_String(Starternummer),
	GGTProzessName = list_to_atom(lists:concat([Praktikumsgruppe, Teamnummer, GGTProzessnummer, Starternummer])),
	{ok, HostName} = inet:gethostname(),
	Datei = lists:concat(["GGTP_",GGTProzessName,"@", HostName, ".log"]),						io:format("Logging-Datei-Name : ~p~n",[Datei]),
	Text = atom_to_list(GGTProzessName)++" Startzeit: "++werkzeug:timeMilliSecond()++" mit PID "++pid_to_list(self())++" auf "++werkzeug:to_String(node())++"\r\n",
	werkzeug:logging(Datei, Text),
	register(GGTProzessName,self()),
	net_adm:ping(NameserviceNode),
	timer:sleep(1000),
	registerNS(Datei,ArbeitsZeit,TermZeit,GGTProzessName,{NameserviceName, NameserviceNode},Koordinator, Quote).
	
registerNS(Datei,ArbeitsZeit,TermZeit,GGTProzessName,NameS,Koordinator, Quote) ->
	NameS ! {self(),{rebind,GGTProzessName,node()}},								% 05 out
	timer:sleep(500),
	receive
		ok ->																		% 05 in
			werkzeug:logging(Datei, "beim Namensdienst und auf Node lokal registriert.\r\n"),
			hello(Datei,ArbeitsZeit,TermZeit,GGTProzessName,NameS,Koordinator, Quote);
		Anything -> 
			Text = lists:concat(["GGT: registerNS unbekannte Nachricht erhalten: '",werkzeug:to_String(Anything),"'\r\n"]), werkzeug:logging(Datei, Text),
			registerNS(Datei,ArbeitsZeit,TermZeit,GGTProzessName,NameS,Koordinator, Quote)
	end.
	
hello(Datei,ArbeitsZeit,TermZeit,GGTProzessName,NameS,Koordinator, Quote) ->
	Koordinator ! {hello,GGTProzessName},											% 06 out
	werkzeug:logging(Datei, "beim Koordinator gemeldet.\r\n"),
	receive
		{setneighbors,LeftN,RightN} ->												% 09 in
			werkzeug:logging(Datei, "Linker Nachbar "++atom_to_list(LeftN)++" ("++atom_to_list(LeftN)++") gebunden.\r\n"),
			werkzeug:logging(Datei, "Rechter Nachbar "++atom_to_list(RightN)++" ("++atom_to_list(RightN)++") gebunden.\r\n"),
			Timer = werkzeug:reset_timer(null, TermZeit, shutdown),
			loop(Datei,ArbeitsZeit,TermZeit,Timer,GGTProzessName,NameS,Koordinator, Quote,LeftN,RightN,0,0);
		Anything -> 
			Text = lists:concat(["GGT: hello unbekannte Nachricht erhalten: '",werkzeug:to_String(Anything),"'\r\n"]), werkzeug:logging(Datei, Text),
			hello(Datei,ArbeitsZeit,TermZeit,GGTProzessName,NameS,Koordinator, Quote)
	end.

loop(Datei,ArbeitsZeit,TermZeit,Timer,GGTProzessName,NameS,Koordinator, Quote,LeftN,RightN,InitMi,InitY) ->
	io:format("ggt-loop~n"),
	receive
		{setpm,Mi} ->																		% 05 in
			werkzeug:logging(Datei, lists:concat(["setpm: ",Mi,". (",atom_to_list(GGTProzessName), ")\r\n"])),
			loop(Datei,ArbeitsZeit,TermZeit,Timer,GGTProzessName,NameS,Koordinator, Quote,LeftN,RightN,Mi,InitY);
			
		{sendy,Y} ->																		% 05 in
			TimerNeu = werkzeug:reset_timer(Timer, TermZeit, shutdown),
			werkzeug:logging(Datei, lists:concat(["sendy: ",Y,". (",atom_to_list(GGTProzessName), ")\r\n"])),
			GggtPID = spawn(fun() -> calculate(Datei,self(),ArbeitsZeit,TermZeit,GGTProzessName,NameS,Koordinator, Quote,LeftN,RightN,InitMi,Y) end),
			loop(Datei,ArbeitsZeit,TermZeit,TimerNeu,GGTProzessName,NameS,Koordinator, Quote,LeftN,RightN,InitMi,Y);
			
		{PID,{vote,NachbarName}} ->																		% 05 in
			io:format("ich stimme zu");
		
		shutdown ->
			shutdown(GGTProzessName,NameS);
		
		Anything -> 
			Text = lists:concat(["GGT: loop unbekannte Nachricht erhalten: '",werkzeug:to_String(Anything),"'\r\n"]), werkzeug:logging(Datei, Text),
			loop(Datei,ArbeitsZeit,TermZeit,Timer,GGTProzessName,NameS,Koordinator, Quote,LeftN,RightN,InitMi,InitY)
	end.
	
calculate(Datei,GGTNode,ArbeitsZeit,TermZeit,GGTProzessName,NameS,Koordinator, Quote,LeftN,RightN,Mi,Y) ->
	io:format("Mi bekommen~n"),
	timer:sleep(ArbeitsZeit),
	io:format("berechne~n"),
	if Mi > Y ->
		NeueMi = ((Mi-1) rem Y)+1,
			io:format("Neue Mi lautet ... ~p~n",[NeueMi]),
			Koordinator ! {briefmi,{GGTProzessName,NeueMi,now()}},
			LeftN ! {sendy,NeueMi},
			RightN ! {sendy,NeueMi};
		true -> io:format("Warte weiter~n")
%	case Mi > Y of
%			NeueMi = ((Mi-1) rem Y)+1,
%			io:format("Neue Mi lauter ... ~p~n",[NeueMi]);
%		false ->
%			io:format("Warte weiter~n")
	end.
		
	
	%TODO
	%calculate(Datei,ArbeitsZeit,TermZeit,GGTProzessName,NameS,Koordinator, Quote,LeftN,RightN,Mi).
	
shutdown(GGTProzessName,NameS) ->
	io:format("Terminierungsanfrage gestartet~n"),
	NameS ! {self(),{multicast,vote,GGTProzessName}}.
	