-module(s).
-compile(export_all).	% ersetzen durch -export([start/0]).


go(0,_) ->
	io:format("alle Starter gestartet...~n");
	
go(Anzahl,Start) ->
	start(Start),
	go(Anzahl-1,Start+1).

start(Starternummer) ->	
	CFGFile = "ggt.cfg",															io:format("~nStarter ~p wurde gestartet ...~n",[Starternummer]),
	{ok, HostName} = inet:gethostname(),
	Datei = lists:concat(["ggtSTARTER_", integer_to_list(Starternummer), "@", HostName, ".log"]),io:format("Logging-Datei-Name :                         '~p'~n",[Datei]),
	Text = lists:concat(["Starter_", integer_to_list(Starternummer), "-", werkzeug:to_String(node()), " Startzeit: ", werkzeug:timeMilliSecond(), " mit PID ", pid_to_list(self()), "\r\n"]),
	werkzeug:logging(Datei, Text),
	case file:consult(CFGFile) of
		{ok, Config} -> werkzeug:logging(Datei,CFGFile++" geöffnet...\r\n");
		{error, {Line, Mod, Term}} -> ErrMSG = lists:concat([CFGFile++" Fehler in Zeile ",werkzeug:to_String(Line),
															 " Mod ",werkzeug:to_String(Mod)," Term ",werkzeug:to_String(Term)]),
										werkzeug:logging(Datei,ErrMSG),
										Config = [];
		{error, Something} -> ErrMSG = lists:concat([CFGFile++" Fehler:",werkzeug:to_String(Something),"\r\n"]),
							  werkzeug:logging(Datei,ErrMSG),
							  Config = [];
		_error -> Config = []
	end,
	
	{ok, PraktikumsGruppe} = werkzeug:get_config_value(praktikumsgruppe, Config),	io:format("PraktikumsGruppe aus '"++CFGFile++"' ausgelesen: ~p~n",[PraktikumsGruppe]),
	{ok, TeamNummer} = werkzeug:get_config_value(teamnummer, Config),				io:format("TeamNummer       aus '"++CFGFile++"' ausgelesen: ~p~n",[TeamNummer]),
	{ok, NameserviceNode} = werkzeug:get_config_value(nameservicenode, Config),		io:format("NameserviceNode  aus '"++CFGFile++"' ausgelesen: ~p~n",[NameserviceNode]),
	{ok, NameserviceName} = werkzeug:get_config_value(nameservicename, Config),		io:format("NameserviceName  aus '"++CFGFile++"' ausgelesen: ~p~n",[NameserviceName]),
	{ok, KoordinatorName} = werkzeug:get_config_value(koordinatorname, Config),		io:format("KoordinatorName  aus '"++CFGFile++"' ausgelesen: ~p~n",[KoordinatorName]),
	werkzeug:logging(Datei,CFGFile++" gelesen...\r\n"),
	
	net_adm:ping(NameserviceNode),
	timer:sleep(1000),
	NameS = {NameserviceName, NameserviceNode}, io:format("Nameservice -> '~p'~n",[NameS]),
	werkzeug:logging(Datei,"Nameservice gebunden...\r\n"),
	
	NameS ! {self(), {lookup, KoordinatorName}},									% 02 out
	receive
		{pin,{Name,Node}} ->														% 02 in
			werkzeug:logging(Datei,"Koordinator " ++ werkzeug:to_String(KoordinatorName) ++ " (" ++ werkzeug:to_String(Name) ++ ") gebunden.\r\n"),
			Koordinator = {Name,Node},
			Koordinator ! {self(), getsteeringval},									% 03 out
			receive
				{steeringval, ArbeitsZeit, TermZeit, Quote, GGTProzessnummer} ->	% 04 in
					werkzeug:logging(Datei,"getsteeringval: " ++ werkzeug:to_String(ArbeitsZeit) ++ " Arbeitszeit ggT; " ++ werkzeug:to_String(TermZeit) ++ " Wartezeit Terminierung ggT; "++ werkzeug:to_String(Quote) ++ " Abstimmungsquote ggT; " ++ werkzeug:to_String(GGTProzessnummer) ++ "-te GGT Prozess.\r\n" ),
					startGGTs(ArbeitsZeit, TermZeit, PraktikumsGruppe, TeamNummer, GGTProzessnummer, Starternummer, NameS, Koordinator, Quote)
			end;

		not_found ->
			io:format("Koordinator nicht gefunden.~n")
	end.
	
	
startGGTs(_, _, _, _, 0, _, _, _, _) ->
	ok;
	
startGGTs(ArbeitsZeit, TermZeit, PraktikumsGruppe, TeamNummer, GGTProzessnummer, Starternummer, NameS, Koordinator, Quote) ->
	erlang:spawn(g, start, [ArbeitsZeit, TermZeit, PraktikumsGruppe, TeamNummer, GGTProzessnummer, Starternummer, NameS, Koordinator, Quote]),
	startGGTs(ArbeitsZeit, TermZeit, PraktikumsGruppe, TeamNummer, GGTProzessnummer-1, Starternummer, NameS, Koordinator, Quote).
	