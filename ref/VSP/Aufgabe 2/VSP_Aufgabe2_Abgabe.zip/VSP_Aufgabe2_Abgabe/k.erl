-module(k).
-compile(export_all).	% ersetzen durch -export([start/0]).

start() ->	
	CFGFile = "koordinator.cfg",													io:format("~nKoordinator wurde gestartet ...~n~n"),
	{ok, HostName} = inet:gethostname(),
	Datei = lists:concat(["koordinator@", HostName, ".log"]),						io:format("Logging-Datei-Name : ~p~n",[Datei]),
	Text = werkzeug:to_String(node())++" Startzeit: "++werkzeug:timeMilliSecond()++" mit PID "++pid_to_list(self())++"\r\n",
	werkzeug:logging(Datei, Text),
	case file:consult(CFGFile) of
		{ok, Config} -> werkzeug:logging(Datei,CFGFile++" geöffnet...\r\n");
		{error, {Line, Mod, Term}} -> ErrMSG = lists:concat(["Koordinator: "++CFGFile++" Fehler in Zeile ",werkzeug:to_String(Line),
															 " Mod ",werkzeug:to_String(Mod)," Term ",werkzeug:to_String(Term)]),
										werkzeug:logging(Datei,ErrMSG),
										Config = [];
		{error, Something} -> ErrMSG = lists:concat(["Koordinator: "++CFGFile++" Fehler:",werkzeug:to_String(Something),"\r\n"]),
							  werkzeug:logging(Datei,ErrMSG),
							  Config = [];
		_error -> Config = []
	end,
	{ok, ArbeitsZeit} = werkzeug:get_config_value(arbeitszeit, Config),				io:format("ArbeitsZeit      aus '"++CFGFile++"' ausgelesen: ~p~n",[ArbeitsZeit]),
	{ok, TermZeit} = werkzeug:get_config_value(termzeit, Config),					io:format("TermZeit         aus '"++CFGFile++"' ausgelesen: ~p~n",[TermZeit]),
	{ok, GGTProzessAnz} = werkzeug:get_config_value(ggtprozessnummer, Config),		io:format("GGTProzessnummer aus '"++CFGFile++"' ausgelesen: ~p~n",[GGTProzessAnz]),
	{ok, NameserviceNode} = werkzeug:get_config_value(nameservicenode, Config),		io:format("NameserviceNode  aus '"++CFGFile++"' ausgelesen: ~p~n",[NameserviceNode]),
	{ok, NameserviceName} = werkzeug:get_config_value(nameservicename, Config),		io:format("NameserviceName  aus '"++CFGFile++"' ausgelesen: ~p~n",[NameserviceName]),
	{ok, KoName} = werkzeug:get_config_value(koordinatorname, Config),				io:format("KoordinatorName  aus '"++CFGFile++"' ausgelesen: ~p~n",[KoName]),
	{ok, Quote} = werkzeug:get_config_value(quote, Config),							io:format("Quote            aus '"++CFGFile++"' ausgelesen: ~p~n",[Quote]),
	{ok, Korrigieren} = werkzeug:get_config_value(korrigieren, Config),				io:format("Korrigieren      aus '"++CFGFile++"' ausgelesen: ~p~n",[Korrigieren]),
	werkzeug:logging(Datei,CFGFile++" gelesen...\r\n"),
	
	net_adm:ping(NameserviceNode),
	timer:sleep(1000),
%	NameS = {NameserviceName, NameserviceNode}, io:format("Nameservice -> '~p'~n",[NameS]),
	NameS = global:whereis_name(NameserviceName), io:format("Nameservice -> '~p'~n",[NameS]),
	werkzeug:logging(Datei,"Nameservice gebunden...\r\n"),
	KoPID = spawn(fun() -> registerNS(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren) end),
	register(KoName,KoPID),
	werkzeug:logging(Datei,"lokal registriert...\r\n").
	

registerNS(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren) ->
	KoNode = node(),
	NameS ! {self(),{rebind,KoName,KoNode}},										% 01 out
	receive
	
		ok ->																		% 01 in
			werkzeug:logging(Datei, "beim Namensdienst registriert.\r\n"),
			initial(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,[]);
			
		Anything -> 
			Text = lists:concat(["Koordinator: registerNS unbekannte Nachricht erhalten: '",werkzeug:to_String(Anything),"'\r\n"]), werkzeug:logging(Datei, Text),
			registerNS(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren)
			
	end.

initial(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTList) ->
	receive
	
		{PID,getsteeringval} when is_pid(PID) ->									% 03 in
			werkzeug:logging(Datei, "getsteeringval: " ++ pid_to_list(PID) ++ " ("++ werkzeug:to_String(GGTProzessAnz) ++").\r\n"),
			PID ! {steeringval,ArbeitsZeit,TermZeit,Quote,GGTProzessAnz},			% 04 out
			GGTListe = wait_for_hello(Datei,GGTProzessAnz,GGTList),
			initial(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTListe);
			
		step -> 																	% 07 in
			werkzeug:logging(Datei, "Anmeldefrist für ggT-Prozesse abgelaufen. Vermisst werden aktuell 0 ggT-Prozesse..\r\n"),
			GGTshuffled = werkzeug:shuffle(GGTList),
			io:format("Listen-Länge:~p~n",[length(GGTshuffled)]),
			[H|_] = GGTshuffled,
			setneighbors(Datei,GGTshuffled,lists:last(GGTshuffled),H,NameS),
			werkzeug:logging(Datei, "Alle ggT-Prozesse gebunden.\r\n"),
			werkzeug:logging(Datei, "Alle ggT-Prozesse über Nachbarn informiert.\r\n"),
			werkzeug:logging(Datei, "Ring wird/wurde erstellt, Koordinator geht in den Zustand 'Bereit für Berechnung'.\r\n"),
			bereit(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTshuffled);
			
		kill ->
			beenden(Datei,NameS,KoName,GGTList);
		
		Anything -> 
			Text = lists:concat(["Koordinator: initial unbekannte Nachricht erhalten: '",werkzeug:to_String(Anything),"'\r\n"]), werkzeug:logging(Datei, Text),
			initial(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTList)
	
	end.

wait_for_hello(_Datei,0,GGTList) ->
	io:format("alle ggt laufen...~n"),
	GGTList;
	
wait_for_hello(Datei,GGTProzessAnz,GGTList) ->
	receive
		{hello,GGTProzessName} when is_atom(GGTProzessName) ->						% 06 in
			werkzeug:logging(Datei, "hello " ++ atom_to_list(GGTProzessName) ++ " ("++ werkzeug:to_String(GGTProzessAnz) ++").\r\n"),
			wait_for_hello(Datei,GGTProzessAnz-1,GGTList++[GGTProzessName]);
		step -> 
			werkzeug:logging(Datei, "Anmeldefrist für ggT-Prozesse abgelaufen. Vermisst werden aktuell "++werkzeug:to_String(GGTProzessAnz)++" ggT-Prozesse..\r\n"),
			GGTList
	end.
	
setneighbors(Datei,[Mitte],Links,Rechts,NameS) ->
	msg_nb(Datei,Mitte,Links,Rechts,NameS),
	io:format("setneighbors links:~p mitte:~p rechts:~p ~n",[Links,Mitte,Rechts]);
setneighbors(Datei,[Mitte,Rechts],Links,Erster,NameS) ->
	msg_nb(Datei,Mitte,Links,Rechts,NameS),
	io:format("setneighbors links:~p mitte:~p rechts:~p ~n",[Links,Mitte,Rechts]),
	setneighbors(Datei,[Rechts],Mitte,Erster,NameS);
setneighbors(Datei,[Mitte,Rechts|Rest],Links,Erster,NameS) ->
	msg_nb(Datei,Mitte,Links,Rechts,NameS),
	io:format("setneighbors links:~p mitte:~p rechts:~p ~n",[Links,Mitte,Rechts]),
	setneighbors(Datei,[Rechts|Rest],Mitte,Erster,NameS).

msg_nb(Datei,GGTN,LeftN,RightN,NameS) ->
	NameS ! {self(),{lookup,GGTN}},													% 08 out
	receive
		{pin,{Name,Node}} ->														% 08 in
			werkzeug:logging(Datei,"ggT-Prozess " ++ atom_to_list(Name) ++ " (" ++ atom_to_list(Name) ++ ") auf "++werkzeug:to_String(Node)++" gebunden.\r\n"),
			GGT = {Name,Node},
			GGT ! {setneighbors,LeftN,RightN},										% 09 out
			werkzeug:logging(Datei,"ggT-Prozess " ++ atom_to_list(Name) ++ " (" ++ werkzeug:to_String(Node) ++ ") über linken ("++atom_to_list(LeftN)++") und rechten ("++atom_to_list(RightN)++") Nachbarn informiert.\r\n");
		not_found ->
			io:format("GGT nicht gefunden.~n")
	end.
	
bereit(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTshuffled) ->
	io:format("bereit~n"),
	receive
		{calc,WggT} ->
			io:format("Berechnung mit dem Wert ~p~n", [WggT]),
			NewGGTList = werkzeug:shuffle(GGTshuffled),
			Length = length(NewGGTList),
			GGTinform = max(round(Length * 0.2 + 0.5),2),
			MiListe = werkzeug:bestimme_mis(WggT,length(GGTshuffled)), % TODO ob die Anzahl groesser 2 ist
			YListe = werkzeug:bestimme_mis(WggT,GGTinform), % TODO ob die Anzahl groesser 2 ist
			sendInitialMi(NameS, MiListe, NewGGTList),
			sendInitialY(NameS,YListe, NewGGTList, GGTinform);
				
		
		{briefmi,{GGTProName,CMi,CZeit}} when is_atom(GGTProName) and is_atom(CMi) and is_atom(CZeit) ->
			werkzeug:logging(Datei, atom_to_list(GGTProName) ++ " meldet neues Mi " ++ atom_to_list(CMi) ++ " um \"" ++ atom_to_list(CZeit) ++ "\" (" ++ werkzeug:timeMilliSecond() ++").\r\n"),
			% aktualisiere die Liste der GGTs mit aktuellen berechneten Mis
			bereit(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTshuffled);
		
		{PID,briefterm,{GGTProName,CMi,CZeit}} when is_atom(GGTProName) and is_atom(CMi) and is_atom(CZeit) ->
			werkzeug:logging(Datei, atom_to_list(GGTProName) ++ " meldet Terminierung mit ggT " ++ atom_to_list(CMi) ++ " um \"" ++ atom_to_list(CZeit) ++ "\" (" ++ werkzeug:timeMilliSecond() ++").\r\n"),
			% aktualisiere die Liste der GGTs mit aktuellen berechneten Mis
			%case Korrigieren of
			%	0 ->
			%		werkzeug:logging(Datei, "Das Ergebnis der Berechung lautet: " ++ werkzeug:to_String(CMi));
			%	1 ->
			%		% berechne kleinsten ggT
			%		KleinsteGGT = 1; % hier wird der berechnete Wert statt 1 stehen
			%		% vergleiche den aktuellen Wert mit dem kleinsten:
			%		case CMi > KleinsteGGT of
			%			true -> 
			%				werkzeug:logging(Datei, "Berechnung wird gleich fortgesetzt, da die berechnete Zahl " ++ werkzeug:to_String(CMi) ++ " groesser als die notwendige ggT Zahl " ++ werkzeug:to_String(SmalllestGGT) ++ "ist\r\n"),
			%				PID ! {sendy, KleinsteGGT};
			%			false ->
			%				werkzeug:logging(Datei, "Endergebnis der Berechnung lautet " ++ werkzeug:to_String(CMi) ++ "\r\n")
			%		end
			%end,
			bereit(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTshuffled);
			
		reset ->
			werkzeug:logging(Datei, "reset-Befehl angekommen, GGTs werden runtergefahren\r\n"),
			killGGTs(Datei,NameS, GGTshuffled);
		prompt ->
			werkzeug:logging(Datei, "prompt-Befehl angekommen\r\n"),
			getCurrentMis(NameS, GGTshuffled),
			bereit(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTshuffled);
		nudge ->
			werkzeug:logging(Datei, "nudge-Befehl angekommen\r\n"),
			nudgeGGTs(NameS, GGTshuffled),
			bereit(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTshuffled);
		toggle ->
			werkzeug:logging(Datei, "toggle-Befehl angekommen\r\n"),
			bereit(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,abs(Korrigieren-1),GGTshuffled);
		{mi,Mi} ->
			werkzeug:logging(Datei, "Nach TellMi ist der Wert angekommen: " ++ werkzeug:to_String(Mi) ++ "\r\n"),
			bereit(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTshuffled);
		{pongGGT, GGTname} ->
			werkzeug:logging(Datei, "Pong angekommen von " ++ werkzeug:to_String(GGTname) ++ "\r\n"),
			bereit(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTshuffled);
		kill ->
			beenden(Datei,NameS,KoName,GGTshuffled);
		
		Anything -> 
			Text = lists:concat(["Koordinator: bereit unbekannte Nachricht erhalten: '",werkzeug:to_String(Anything),"'\r\n"]), werkzeug:logging(Datei, Text),
			bereit(Datei,ArbeitsZeit,TermZeit,GGTProzessAnz,NameS,KoName,Quote,Korrigieren,GGTshuffled)
	
	end.
	
beenden(Datei,NameS,KoName,GGTList) ->
	io:format("beenden~n"),
	killGGTs(Datei,NameS,GGTList),
	NameS ! {self(), {unbind, KoName}},
	werkzeug:logging(Datei, "Koordinator wurde terminiert...\n").
	
killGGTs(Datei, NameS, []) ->
	werkzeug:logging(Datei, "Allen ggT-Prozessen ein 'kill' gesendet'n"),
	ok;
killGGTs(Datei,NameS,[GGT | Rest]) ->
	NameS ! {self(), {lookup, GGT}},
	receive 
        not_found -> werkzeug:logging(Datei, "Der zu terminierende GGT-Prozess nicht gefunden:" ++ werkzeug:to_String(GGT) ++ "\r\n"); 
        {pin,{Name,Node}} ->
        	{Name,Node} ! kill,
        	werkzeug:logging(Datei, "kill-Befehl an GGT " ++ werkzeug:to_String(GGT) ++ " ist gesendet")
	end,
	killGGTs(Datei,NameS, Rest).	

	
sendInitialMi(Nameservice,[], NewGGTList) ->
	io:format("alle Mis gesendet.~n");
sendInitialMi(Nameservice,MiListe, NewGGTList) ->
	% TODO Anzahl darf nicht kleiner 2 sein
	io:format("Initialisieren Mi Werte ~n"),
	[GGT | GGTS] = NewGGTList,
	io:format("Miliste :~p~n",[MiListe]),
	[Mi | Mis] = MiListe,
	Nameservice ! {self(), {lookup, GGT}},
	receive 
        not_found -> io:format("GGT Prozess nicht gefunden:" ++ werkzeug:to_String(GGT) ++ "~n"); 
        {pin,{Name,Node}} ->
			Prozess = {Name,Node},
			io:format("Mi wird uebergeben an ~p~n",[Prozess]),
			Prozess ! {setpm,Mi},
			Text = lists:concat(["ggT-Prozess ", atom_to_list(GGT), " (",Node,") initiales Mi  ",Mi, " gesendet.\r\n"]);
		Anything -> 
			Text = lists:concat(["Koordinator: sendInitialMi unbekannte Nachricht erhalten: '",werkzeug:to_String(Anything),"'\r\n"]), io:format(Text)
	end,
	sendInitialMi(Nameservice,Mis,GGTS).
	
	
sendInitialY(Nameservice,[], NewGGTList, GGTinform) ->
	io:format("alle Ys gesendet.~n");
sendInitialY(Nameservice,YListe, NewGGTList, GGTinform) when length(NewGGTList) >= GGTinform ->
	io:format("Initialisieren Y Werte ~n"),
	[GGT | GGTS] = NewGGTList,
	io:format("Yliste :~p~n",[YListe]),
	[Y | Ys] = YListe,
	Nameservice ! {self(), {lookup, GGT}},
	receive 
        not_found -> io:format("GGT Prozess nicht gefunden:" ++ werkzeug:to_String(GGT) ++ "~n"); 
        {pin,{Name,Node}} ->
			Prozess = {Name,Node},
			io:format("Y wird uebergeben an ~p~n",[Prozess]),
			Prozess ! {sendy,Y},
			Text = lists:concat(["ggT-Prozess ", atom_to_list(GGT), " (",Node,") initiales Y  ",Y, " gesendet.\r\n"]);
		Anything -> 
			Text = lists:concat(["Koordinator: sendInitialY unbekannte Nachricht erhalten: '",werkzeug:to_String(Anything),"'\r\n"]), io:format(Text)
	end,
	sendInitialY(Nameservice,Ys,GGTS,GGTinform);
sendInitialY(_Nameservice,_YListe,_NewGGTList,_GGTinform) ->
	io:format("Zu niedrige Anzahl von GGTs~n").
	
	
getCurrentMis(_, []) ->
	ok;
getCurrentMis(Nameservice, [GGT|Rest]) ->
	Nameservice ! {self(), {lookup, GGT}},
	receive 
        not_found -> io:format("GGT Prozess nicht gefunden:" ++ werkzeug:to_String(GGT) ++ "~n"); 
        {pin,{Name,Node}} ->
			{Name,Node} ! {self(),tellmi},
			getCurrentMis(Nameservice, Rest)
	end.

nudgeGGTs(_, []) ->
	ok;
nudgeGGTs(Nameservice, [GGT|Rest]) ->
	Nameservice ! {self(), {lookup, GGT}},
	receive 
        not_found -> io:format("GGT Prozess nicht gefunden:" ++ werkzeug:to_String(GGT) ++ "~n"); 
        {pin,{Name,Node}} -> {self(), pingGGT}
	end,
	nudgeGGTs(Nameservice, Rest).
